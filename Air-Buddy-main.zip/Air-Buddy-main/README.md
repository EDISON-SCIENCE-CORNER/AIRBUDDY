# Air Buddy 🎯

[![TypeScript](https://img.shields.io/badge/TypeScript-007ACC?style=for-the-badge&logo=typescript&logoColor=white)](https://www.typescriptlang.org/)
[![React](https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB)](https://reactjs.org/)
[![Node.js](https://img.shields.io/badge/Node.js-43853D?style=for-the-badge&logo=node.js&logoColor=white)](https://nodejs.org/)
[![Express.js](https://img.shields.io/badge/Express.js-404D59?style=for-the-badge&logo=express&logoColor=white)](https://expressjs.com/)
[![MongoDB](https://img.shields.io/badge/MongoDB-4EA94B?style=for-the-badge&logo=mongodb&logoColor=white)](https://www.mongodb.com/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-38B2AC?style=for-the-badge&logo=tailwind-css&logoColor=white)](https://tailwindcss.com/)

Pen for Monitoring Health and Environmental Parameters of School Going Children - A comprehensive health monitoring and environmental tracking system for school children with advanced sensor integration and notifications.

## 🚀 Technical Stack & Features

### 🔧 Backend (Node.js + TypeScript)

- **🛠️ Framework**: Express.js with TypeScript
- **🗄️ Database**: MongoDB with Mongoose and Typegoose for type-safe models
- **🔐 Authentication**: JWT-based authentication with secure cookie storage
- **⚡ Real-time Communication**: WebSocket integration using Socket.IO
- **🔒 Security Features**:
  - Password salting and hashing using bcrypt
  - CORS protection
  - Environment variable configuration
- **📨 Notification System**:
  - Web Push notifications using web-push
  - Email notifications via Nodemailer (Gmail)
- **🔌 API Features**:
  - RESTful endpoints
  - Protected routes with middleware authentication
  - User management
  - Sensor data history
  - Real-time updates

### 🎨 Frontend (React + TypeScript)

- **⚛️ Framework**: React with TypeScript
- **🏗️ Build Tool**: Vite for fast development and optimized builds
- **💅 Styling**: Tailwind CSS for modern, responsive design
- **🧩 UI Components**:
  - Custom device cards
  - Navigation system
  - Real-time data display
- **✨ Features**:
  - Real-time sensor data visualization
  - User authentication
  - Responsive layout
  - Dark theme with gradient backgrounds

## 🛠️ Project Setup

### 📝 Environment Variables

1. Copy the `.env.example` file to create a new `.env` file:
   ```bash
   cp be/.env.example be/.env
   ```
2. Update the following variables in your .env file:
   - `PORT`: Backend server port (default: 5001)
   - `MONGODB_URI`: MongoDB connection string
   - `CORS_ORIGIN`: Frontend application URL
   - `GMAIL_USERNAME`: Your Gmail address
   - `GMAIL_PASSWORD`: Your Gmail app password
   - `VAPID_PUBLIC_KEY`: Web Push public key
   - `VAPID_PRIVATE_KEY`: Web Push private key
   - `VAPID_SUBJECT`: mailto link for Web Push

### 📧 Gmail App Password Setup

1. Go to your Google Account settings
2. Navigate to Security > 2-Step Verification
3. Scroll to "App passwords"
4. Generate a new app password for "Mail"
5. Copy the generated password to your .env file

### 🔔 Web Push (VAPID) Setup

1. Generate VAPID keys from [https://www.attheminute.com/vapid-key-generator](https://www.attheminute.com/vapid-key-generator)
2. Copy the generated public and private keys to your .env file
3. Set the VAPID_SUBJECT to your email address (format: mailto:your.email@domain.com)

### 🗄️ MongoDB Setup

1. Using MongoDB Atlas:

   - Create a free account at [MongoDB Atlas](https://www.mongodb.com/cloud/atlas)
   - Create a new cluster
   - Get your connection string
   - Update MONGODB_URI in .env file

2. Using Docker (for local development):
   ```bash
   docker-compose up -d
   ```
   This will start a MongoDB instance with the credentials specified in docker-compose.yaml

### 🌱 Initial Setup & Data Seeding

1. Install dependencies for both frontend and backend:

   ```bash
   # Install backend dependencies
   cd be && npm install

   # Install frontend dependencies
   cd ../fe && npm install
   ```

2. Run the seeding script to create initial users:
   ```bash
   cd be && npm run seed
   ```
   This will create:
   - 👑 Admin user: admin@airbuddy.com / Admin@123
   - 👤 Regular user: user@airbuddy.com / User@123

## 💻 Development

### 🚀 Running the Application

1. Start the backend server:

   ```bash
   cd be && npm run dev
   ```

2. Start the frontend development server:
   ```bash
   cd fe && npm run dev
   ```

The application will be available at:

- 🎯 Frontend: http://localhost:3003
- ⚙️ Backend: http://localhost:5001

### 📦 Building for Production

1. Build the frontend:

   ```bash
   cd fe && npm run build
   ```

   This will create optimized production build in `be/public` directory

2. Build the backend:

   ```bash
   cd be && npm run build
   ```

3. Start the production server:
   ```bash
   cd be && npm start
   ```

## 🐳 Docker Development Environment

For local development using Docker:

1. Start the MongoDB container:

   ```bash
   docker-compose up -d
   ```

2. MongoDB will be available at:
   - 🏠 Host: localhost
   - 🔌 Port: 27017
   - 👤 Username: admin
   - 🔑 Password: secret

The docker-compose setup includes:

- 🗄️ MongoDB instance
- 💾 Persistent volume for data storage
- 🔄 Automatic container restart
