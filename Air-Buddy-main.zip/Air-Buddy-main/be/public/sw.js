console.log("Service Worker Loaded");

self.addEventListener("push", (event) => {
  console.log("[Service Worker] Push Received.");
  console.log(
    `[Service Worker] Push had this data: "${
      event.data ? event.data.text() : "no data"
    }"`
  );

  let data = {};
  if (event.data) {
    try {
      data = event.data.json();
    } catch (e) {
      data = {
        title: "Push Notification",
        body: event.data.text(),
        icon: "/icon-192x192.png", // Default icon
      };
    }
  }

  const title = data.title || "Push Notification";
  const options = {
    body: data.body || "Something new happened!",
    icon: data.icon || "/icon-192x192.png", // Path to an icon
    badge: data.badge || "/badge-72x72.png", // Path to a badge icon (for Android)
    // Other options: image, actions, data, vibrate, etc.
    data: {
      url: data.url || "/", // URL to open when notification is clicked
    },
  };

  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener("notificationclick", (event) => {
  console.log("[Service Worker] Notification click Received.");
  event.notification.close(); // Close the notification

  // Open the app/URL. event.notification.data.url is the URL passed in showNotification
  const urlToOpen =
    event.notification.data && event.notification.data.url
      ? event.notification.data.url
      : "/";
  event.waitUntil(
    clients.matchAll({ type: "window" }).then((windowClients) => {
      // Check if there is already a window/tab open with the target URL
      for (var i = 0; i < windowClients.length; i++) {
        var client = windowClients[i];
        if (client.url === urlToOpen && "focus" in client) {
          return client.focus();
        }
      }
      // If not, then open the URL in a new window/tab.
      if (clients.openWindow) {
        return clients.openWindow(urlToOpen);
      }
    })
  );
});
