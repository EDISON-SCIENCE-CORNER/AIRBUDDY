import { Request, Response } from "express";
import * as apiKeyService from "../services/api-key.service";

export const generateApiKey = async (req: Request, res: Response) => {
  try {
    const apiKey = await apiKeyService.generateApiKey();
    res.json({ key: apiKey.key });
  } catch (error) {
    res.status(500).json({ message: "Error generating API key" });
  }
};

export const getCurrentApiKey = async (req: Request, res: Response) => {
  try {
    const apiKey = await apiKeyService.getCurrentApiKey();
    if (!apiKey) {
      return res.status(404).json({ message: "No API key found" });
    }
    res.json({ key: apiKey.key });
  } catch (error) {
    res.status(500).json({ message: "Error fetching API key" });
  }
};

export const regenerateApiKey = async (req: Request, res: Response) => {
  try {
    const apiKey = await apiKeyService.regenerateApiKey();
    res.json({ key: apiKey.key });
  } catch (error) {
    res.status(500).json({ message: "Error regenerating API key" });
  }
};
