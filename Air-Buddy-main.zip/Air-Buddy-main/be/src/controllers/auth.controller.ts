import { Request, Response } from "express";
import * as authService from "../services/auth.service";
import { LoginDto } from "../types";

const COOKIE_OPTIONS = {
  httpOnly: true,
  secure: process.env.NODE_ENV === "production",
  sameSite: "strict" as const,
  maxAge: 24 * 60 * 60 * 1000, // 24 hours
};

const PUBLIC_COOKIE_OPTIONS = {
  httpOnly: false, // Allow JavaScript access
  secure: process.env.NODE_ENV === "production",
  sameSite: "strict" as const,
  maxAge: 24 * 60 * 60 * 1000, // 24 hours
};

export const login = async (req: Request, res: Response) => {
  try {
    const loginDto: LoginDto = req.body;
    const { token, user } = await authService.login(loginDto);

    res.cookie("jwt", token, COOKIE_OPTIONS);
    res.cookie("isLoggedIn", "true", PUBLIC_COOKIE_OPTIONS);
    res.json({ user });
  } catch (error) {
    if (error instanceof Error && error.message === "Invalid credentials") {
      res.status(404).json({ message: "Invalid email or password" });
    } else {
      res.status(500).json({ message: "Error during login" });
    }
  }
};

export const logout = (req: Request, res: Response) => {
  res.clearCookie("jwt", COOKIE_OPTIONS);
  res.clearCookie("isLoggedIn", PUBLIC_COOKIE_OPTIONS);
  res.json({ message: "Logged out successfully" });
};
