import { Request, Response } from "express";
import * as pushNotificationService from "../services/push-notification.service";

export const getVapidPublicKey = (req: Request, res: Response) => {
  const publicKey = process.env.VAPID_PUBLIC_KEY;
  if (!publicKey) {
    return res.status(500).json({ error: "VAPID public key not configured" });
  }
  res.send(publicKey);
};

export const subscribe = async (req: Request, res: Response) => {
  try {
    const subscription = req.body;
    await pushNotificationService.addSubscription(subscription);
    console.log("Subscription received:", subscription);

    await pushNotificationService.sendWelcomeNotification(subscription);
    res.status(201).json({ message: "Subscription added successfully." });
  } catch (error) {
    console.error("Error in subscription:", error);
    res.status(500).json({ error: "Failed to process subscription" });
  }
};

export const sendNotification = async (req: Request, res: Response) => {
  try {
    const { title, body, icon } = req.body;
    await pushNotificationService.sendPushNotificationToAll({ title, body });
    res.status(200).json({ message: "Notifications sent successfully." });
  } catch (error) {
    console.error("Error during notification sending process:", error);
    if (
      error instanceof Error &&
      error.message === "No subscribers to send notifications to."
    ) {
      return res.status(400).json({ error: error.message });
    }
    res.status(500).json({ error: "Failed to send notifications" });
  }
};
