import { Request, Response } from "express";
// import { checkAndSendNotification } from "../services/notification.service";
import { checkAndSendNotification } from "../services/notification.service";
import * as sensorHistoryService from "../services/sensor-history.service";

export const getLatestData = async (req: Request, res: Response) => {
  try {
    const data = await sensorHistoryService.getLatestData();
    res.json(data);
  } catch (error) {
    res
      .status(500)
      .json({ message: "Error fetching latest sensor data", error });
  }
};

export const getHistoryData = async (req: Request, res: Response) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 20;
    const period = (req.query.period as string) || "today";
    const data = await sensorHistoryService.getHistoryData(page, limit, period);
    res.json(data);
  } catch (error) {
    res.status(500).json({ message: "Error fetching sensor history", error });
  }
};

export const updateSensorData = async (req: Request, res: Response) => {
  try {
    const updatedData = await sensorHistoryService.update(req.body);
    req.io?.emit("sensor:latest-data", updatedData);
    checkAndSendNotification(updatedData);
    res.json(updatedData);
  } catch (error) {
    res.status(400).json({ message: "Error updating sensor data", error });
  }
};
