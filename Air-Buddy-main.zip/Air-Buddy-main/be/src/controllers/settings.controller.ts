import { Request, Response } from "express";
import * as settingsService from "../services/settings.service";

export const getSettings = async (req: Request, res: Response) => {
  try {
    const settings = await settingsService.getSettings();
    res.json(settings || { settings: {} });
  } catch (error) {
    res.status(500).json({ message: "Error fetching settings" });
  }
};

export const updateSettings = async (req: Request, res: Response) => {
  try {
    const settingsData = req.body;
    const settings = await settingsService.updateSettings(settingsData);
    res.json(settings);
  } catch (error) {
    res.status(500).json({ message: "Error updating settings" });
  }
};
