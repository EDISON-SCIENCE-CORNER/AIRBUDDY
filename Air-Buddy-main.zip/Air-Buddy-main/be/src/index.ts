import cookieParser from "cookie-parser";
import cors from "cors";
import dotenv from "dotenv";
import express from "express";
import { createServer } from "http";
import mongoose from "mongoose";
import path from "path";
import { Server } from "socket.io";
import webpush from "web-push";
import { authenticate } from "./middlewares/auth.middleware";
import { combinedAuth } from "./middlewares/combined-auth.middleware";
import apiKeyRoutes from "./routes/api-key.route";
import authRoutes from "./routes/auth.route";
import pushNotificationRoutes from "./routes/push-notification.routes";
import sensorHistoryRoutes from "./routes/sensor-history.route";
import settingsRoutes from "./routes/settings.route";
import userRoutes from "./routes/user.routes";
import { setupSocketHandlers } from "./socket";

dotenv.config();

const publicVapidKey = process.env.VAPID_PUBLIC_KEY || "YOUR_PUBLIC_VAPID_KEY";
const privateVapidKey =
  process.env.VAPID_PRIVATE_KEY || "YOUR_PRIVATE_VAPID_KEY";
const vapidSubject =
  process.env.VAPID_SUBJECT || "mailto:your_email@example.com";

webpush.setVapidDetails(vapidSubject, publicVapidKey, privateVapidKey);

declare global {
  namespace Express {
    interface Request {
      io: Server;
    }
  }
}

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: "*",
    methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    credentials: true,
    allowedHeaders: ["*"],
  },
  transports: ["websocket", "polling"],
});

// Middleware
app.use(express.json());
app.use(cookieParser());
app.use(
  cors({
    origin: process.env.CORS_ORIGIN || "*",
    methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    credentials: true,
    allowedHeaders: ["*"],
  })
);

// Serve static files from public directory
app.use(express.static(path.join(__dirname, "../public")));

app.use(function (req, res, next) {
  req.io = io;
  next();
});

// MongoDB Connection
const MONGODB_URI = process.env.MONGODB_URI || "";
mongoose
  .connect(MONGODB_URI)
  .then(() => console.log("Connected to MongoDB"))
  .catch((error) => console.error("MongoDB connection error:", error));

// Initialize Socket.IO handlers
setupSocketHandlers(io);

// Routes
app.use("/api/auth", authRoutes);
app.use("/api/notifications", pushNotificationRoutes);
// Protected routes
app.use("/api/api-keys", authenticate, apiKeyRoutes);
app.use("/api/sensor-history", combinedAuth, sensorHistoryRoutes);
app.use("/api/users", authenticate, userRoutes);
app.use("/api/settings", authenticate, settingsRoutes);

// Handle client-side routing - serve index.html for all non-API routes
app.get("*", function (req, res) {
  if (!req.path.startsWith("/api/")) {
    res.sendFile(path.join(__dirname, "../public/index.html"));
  } else {
    res.status(404).json({ message: "API route not found" });
  }
});

// Error handling middleware
app.use(
  (
    err: Error,
    req: express.Request,
    res: express.Response,
    next: express.NextFunction
  ) => {
    console.error(err.stack);
    res.status(500).json({ message: "Something went wrong!" });
  }
);

const PORT = process.env.PORT || 5001;
httpServer.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
