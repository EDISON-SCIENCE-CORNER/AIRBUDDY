import { NextFunction, Request, Response } from "express";
import * as apiKeyService from "../services/api-key.service";

export const apiKeyAuth = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const apiKey = req.header("X-API-Key");

    if (!apiKey) {
      return res.status(401).json({ message: "API key is required" });
    }

    const isValid = await apiKeyService.validateApiKey(apiKey);

    if (!isValid) {
      return res.status(401).json({ message: "Invalid API key" });
    }

    next();
  } catch (error) {
    res.status(401).json({ message: "Invalid API key" });
  }
};
