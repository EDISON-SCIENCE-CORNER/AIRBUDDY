import { NextFunction, Request, Response } from "express";
import * as apiKeyService from "../services/api-key.service";
import * as authService from "../services/auth.service";

export const combinedAuth = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    // Check for API Key first
    const apiKey = req.header("X-API-Key");
    if (apiKey) {
      const isValid = await apiKeyService.validateApiKey(apiKey);
      if (isValid) {
        return next();
      }
    }

    // If no API key or invalid API key, try JWT auth
    const token = req.cookies.jwt;
    if (token) {
      const payload = authService.verifyToken(token);
      req.user = payload;
      return next();
    }

    // If neither authentication method is valid
    return res
      .status(401)
      .json({ message: "Authentication required (API key or JWT)" });
  } catch (error) {
    res.status(401).json({ message: "Invalid authentication credentials" });
  }
};
