import { getModelForClass, modelOptions, prop } from "@typegoose/typegoose";
import { Types } from "mongoose";

export interface ApiKey {
  _id: Types.ObjectId;
  id: string;
  key: string;
  // createdAt: Date;
  // updatedAt: Date;
}

@modelOptions({
  schemaOptions: { timestamps: true, toJSON: { virtuals: true } },
})
class ApiKeyClass implements Omit<ApiKey, "id"> {
  _id!: Types.ObjectId;

  @prop({ required: true, unique: true, type: String })
  key!: string;

  get id(): string {
    return this._id.toString();
  }
}

export const ApiKeyModel = getModelForClass(ApiKeyClass);
