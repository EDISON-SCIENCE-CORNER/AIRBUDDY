import { getModelForClass, prop } from "@typegoose/typegoose";

export class PushSubscriptionKeys {
  @prop({ required: true })
  p256dh!: string;

  @prop({ required: true })
  auth!: string;
}

export class PushSubscription {
  @prop({ required: true, unique: true })
  endpoint!: string;

  @prop({ required: true, _id: false })
  keys!: PushSubscriptionKeys;

  @prop({ default: Date.now })
  createdAt?: Date;
}

export const PushSubscriptionModel = getModelForClass(PushSubscription);
