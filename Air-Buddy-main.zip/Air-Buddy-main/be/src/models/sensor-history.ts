import { getModelForClass, modelOptions, prop } from "@typegoose/typegoose";

export interface SensorHistory {
  values: Record<string, number>;
}

@modelOptions({ schemaOptions: { timestamps: true } })
class SensorHistoryClass implements SensorHistory {
  @prop({ type: Object, required: true, default: {} })
  public values!: Record<string, number>;
}

export const SensorHistoryModel = getModelForClass(SensorHistoryClass);
