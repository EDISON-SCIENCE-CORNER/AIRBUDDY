import { getModelForClass, modelOptions, prop } from "@typegoose/typegoose";

export interface Settings {
  settings: Record<string, number>;
}

@modelOptions({
  schemaOptions: { timestamps: true, collection: "settings" },
})
class SettingsClass implements Settings {
  @prop({ type: Object, required: true, default: {} })
  public settings!: Record<string, number>;
}

export const SettingsModel = getModelForClass(SettingsClass);
