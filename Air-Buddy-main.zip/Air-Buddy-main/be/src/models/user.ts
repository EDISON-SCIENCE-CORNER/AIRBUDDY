import { getModelForClass, modelOptions, prop } from "@typegoose/typegoose";
import { Types } from "mongoose";

export interface User {
  _id: Types.ObjectId;
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  passwordSalt: string;
  isAdmin: boolean;
  profilePicUrl?: string;
  isActive: boolean;
}

@modelOptions({
  schemaOptions: { timestamps: true, toJSON: { virtuals: true } },
})
class UserClass implements Omit<User, "id"> {
  _id!: Types.ObjectId;

  @prop({ required: true, type: String })
  firstName!: string;

  @prop({ required: true, type: String })
  lastName!: string;

  @prop({ required: true, unique: true, type: String })
  email!: string;

  @prop({ required: true, type: String })
  password!: string;

  @prop({ required: true, type: String })
  passwordSalt!: string;

  @prop({ default: false, type: Boolean })
  isAdmin!: boolean;

  @prop({ type: String })
  profilePicUrl?: string;

  @prop({ default: true, type: Boolean })
  isActive!: boolean;

  get id(): string {
    return this._id.toString();
  }
}

export const UserModel = getModelForClass(UserClass);
