import { Router } from "express";
import {
  generateApiKey,
  getCurrentApiKey,
  regenerateApiKey,
} from "../controllers/api-key.controller";
import { authenticate } from "../middlewares/auth.middleware";

const router = Router();

// All API key management routes require regular authentication
router.use(authenticate);

router.post("/generate", generateApiKey);
router.get("/current", getCurrentApiKey);
router.post("/regenerate", regenerateApiKey);

export default router;
