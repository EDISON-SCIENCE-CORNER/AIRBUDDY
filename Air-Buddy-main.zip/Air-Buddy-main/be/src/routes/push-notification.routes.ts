import { Router } from "express";
import {
  getVapidPublicKey,
  sendNotification,
  subscribe,
} from "../controllers/push-notification.controller";

const router = Router();

router.get("/vapid-public-key", getVapidPublicKey);
router.post("/subscribe", subscribe);
router.post("/send", sendNotification);

export default router;
