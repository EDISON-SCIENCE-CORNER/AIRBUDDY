import { Router } from "express";
import {
  getHistoryData,
  getLatestData,
  updateSensorData,
} from "../controllers/sensor-history.controller";

const router = Router();

router.get("/latest", getLatestData);
router.get("/", getHistoryData);
router.post("/", updateSensorData);

export default router;
