import dotenv from "dotenv";
import { connect } from "mongoose";
import * as userService from "./services/user.service";

dotenv.config();

const seedUsers = async () => {
  try {
    // Connect to MongoDB
    const MONGODB_URI = process.env.MONGODB_URI || "";
    await connect(MONGODB_URI);
    console.log("Connected to MongoDB");

    // Create admin user
    const adminUser = {
      firstName: "Admin",
      lastName: "User",
      email: "admin@airbuddy.com",
      password: "Admin@123",
      isAdmin: true,
    };

    // Create normal user
    const normalUser = {
      firstName: "Normal",
      lastName: "User",
      email: "user@airbuddy.com",
      password: "User@123",
      isAdmin: false,
    };

    // Try to create users, ignore if they already exist
    try {
      await userService.createUser(adminUser);
      console.log("Admin user created successfully");
    } catch (error) {
      if (error instanceof Error && error.message === "Email already in use") {
        console.log("Admin user already exists");
      } else {
        throw error;
      }
    }

    try {
      await userService.createUser(normalUser);
      console.log("Normal user created successfully");
    } catch (error) {
      if (error instanceof Error && error.message === "Email already in use") {
        console.log("Normal user already exists");
      } else {
        throw error;
      }
    }

    console.log("Seeding completed successfully");
    process.exit(0);
  } catch (error) {
    console.error("Error during seeding:", error);
    process.exit(1);
  }
};

seedUsers();
