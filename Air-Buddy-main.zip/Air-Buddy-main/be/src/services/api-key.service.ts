import { DocumentType } from "@typegoose/typegoose";
import crypto from "crypto";
import { ApiKey, ApiKeyModel } from "../models/api-key";

export const generateApiKey = async (): Promise<DocumentType<ApiKey>> => {
  // Delete any existing API key since we only want one at a time
  await ApiKeyModel.deleteMany({});

  // Generate a new API key
  const key = crypto.randomBytes(32).toString("hex");

  // Create and save the new API key
  const apiKey = await ApiKeyModel.create({ key });
  return apiKey as DocumentType<ApiKey>;
};

export const validateApiKey = async (key: string): Promise<boolean> => {
  const apiKey = await ApiKeyModel.findOne({ key });
  console.log("DEBUG: Validating API key:", key, "Found:", apiKey);
  return !!apiKey;
};

export const getCurrentApiKey =
  async (): Promise<DocumentType<ApiKey> | null> => {
    return ApiKeyModel.findOne();
  };

export const regenerateApiKey = async (): Promise<DocumentType<ApiKey>> => {
  return generateApiKey();
};
