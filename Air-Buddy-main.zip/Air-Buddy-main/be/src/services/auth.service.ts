import jwt from "jsonwebtoken";
import { JwtPayload, LoginDto } from "../types";
import * as userService from "./user.service";

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";
const JWT_EXPIRY = "24h";

export const login = async (loginDto: LoginDto) => {
  const user = await userService.findUserByEmail(loginDto.email);
  if (!user) {
    throw new Error("Invalid credentials");
  }

  const isPasswordValid = await userService.verifyPassword(
    loginDto.password,
    user.password
  );

  if (!isPasswordValid) {
    throw new Error("Invalid credentials");
  }

  const payload: JwtPayload = {
    userId: user.id,
    email: user.email,
    isAdmin: user.isAdmin,
  };

  const token = jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRY });
  return {
    token,
    user: { ...user.toObject(), password: undefined, passwordSalt: undefined },
  };
};

export const verifyToken = (token: string): JwtPayload => {
  try {
    return jwt.verify(token, JWT_SECRET) as JwtPayload;
  } catch (error) {
    throw new Error("Invalid token");
  }
};
