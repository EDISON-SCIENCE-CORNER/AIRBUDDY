import "dotenv/config";
import nodemailer from "nodemailer";

// Constants
const RETRY_COUNT = 3;

// Initialize email transporter
const emailTransporter = initializeEmailTransporter();

function initializeEmailTransporter() {
  if (!process.env.GMAIL_USERNAME || !process.env.GMAIL_PASSWORD) {
    console.warn("Gmail notifications not configured - missing credentials");
    return null;
  }

  return nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: process.env.GMAIL_USERNAME,
      pass: process.env.GMAIL_PASSWORD,
    },
  });
}

export async function sendGmailNotification(
  message: string,
  subject: string,
  recipient: string,
  retryCount = RETRY_COUNT
): Promise<boolean> {
  if (!emailTransporter) {
    return false;
  }

  for (let attempt = 1; attempt <= retryCount; attempt++) {
    try {
      const mailOptions = {
        from: process.env.GMAIL_USERNAME,
        to: recipient,
        subject,
        text: message,
        html: `<p>${message}</p>`,
      };

      await emailTransporter.sendMail(mailOptions);
      console.log(`Email notification sent successfully to ${recipient}`);
      return true;
    } catch (error) {
      console.error(
        `Attempt ${attempt}/${retryCount} - Failed to send email notification to ${recipient}:`,
        error
      );
      if (attempt === retryCount) {
        return false;
      }
      // Wait before retrying (exponential backoff)
      await new Promise((resolve) =>
        setTimeout(resolve, Math.pow(2, attempt) * 1000)
      );
    }
  }
  return false;
}

export async function sendGmailNotificationToAll(
  message: string,
  subject: string,
  recipients: string[]
): Promise<boolean> {
  try {
    const sendPromises = recipients.map((recipient) =>
      sendGmailNotification(message, subject, recipient)
    );

    const results = await Promise.all(sendPromises);
    const allSuccessful = results.every((success) => success);

    if (!allSuccessful) {
      console.warn("Some email notifications failed to send");
    }

    return allSuccessful;
  } catch (error) {
    console.error("Failed to send notifications to all users:", error);
    return false;
  }
}
