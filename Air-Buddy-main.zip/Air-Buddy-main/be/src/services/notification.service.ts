import { SensorHistory } from "../models/sensor-history";
import { SENSORS, SensorType, getAllSensorTypes } from "../types/sensors";
import {
  sendGmailNotification,
  sendGmailNotificationToAll,
} from "./gmail.service";
import { sendPushNotificationToAll } from "./push-notification.service";
import * as settingsService from "./settings.service";
import * as userService from "./user.service";

// Types
interface NotificationThreshold {
  min: number;
  max: number;
  type: SensorType;
  unit: string;
  label: string;
}

interface NotificationTracker {
  [key: string]: Date;
}

// Constants
const NOTIFICATION_COOLDOWN = 15 * 60 * 1000; // 15 minutes in milliseconds

// In-memory notification tracker - initialized from SENSORS object
const lastNotifications: NotificationTracker = getAllSensorTypes().reduce(
  (acc, sensorType) => {
    acc[sensorType] = new Date(0);
    return acc;
  },
  {} as NotificationTracker
);

function canSendNotification(type: SensorType): boolean {
  const now = new Date();
  const lastTime = lastNotifications[type];
  if (now.getTime() - lastTime.getTime() >= NOTIFICATION_COOLDOWN) {
    lastNotifications[type] = now;
    return true;
  }
  return false;
}

async function sendEmailNotificationToAllUsers(
  message: string,
  subject: string
): Promise<boolean> {
  try {
    const users = await userService.findAllUsers();
    return sendGmailNotificationToAll(
      message,
      subject,
      users.map((u) => u.email)
    );
  } catch (error) {
    console.error("Failed to send email notifications to all users:", error);
    return false;
  }
}

function checkSensorValue(
  value: number,
  { min, max, type, unit, label }: NotificationThreshold
): { shouldNotify: boolean; message: string } | null {
  if (value < min) {
    return {
      shouldNotify: true,
      message: `${label} is too low: ${value}${unit} (minimum: ${min}${unit})`,
    };
  }
  if (value > max) {
    return {
      shouldNotify: true,
      message: `${label} is too high: ${value}${unit} (maximum: ${max}${unit})`,
    };
  }
  return null;
}

export async function checkAndSendNotification(
  currentData: SensorHistory
): Promise<void> {
  try {
    const settingsDoc = await settingsService.getSettings();
    if (!settingsDoc) {
      console.log("No settings found, skipping notifications");
      return;
    }

    const settings = settingsDoc.settings;
    const thresholds: NotificationThreshold[] = getAllSensorTypes().map(
      (sensorType) => {
        const sensorConfig = SENSORS[sensorType];
        return {
          type: sensorConfig.type,
          label: sensorConfig.label,
          unit: sensorConfig.unit,
          min: settings[sensorConfig.settingsMinKey] as number,
          max: settings[sensorConfig.settingsMaxKey] as number,
        };
      }
    );

    for (const threshold of thresholds) {
      const value = currentData.values[threshold.type];
      const checkResult = checkSensorValue(value, threshold);

      if (checkResult && canSendNotification(threshold.type)) {
        await Promise.all([
          sendPushNotificationToAll({
            title: "Air Buddy Alert!",
            body: checkResult.message,
          }),
          sendEmailNotificationToAllUsers(
            checkResult.message,
            "Air Buddy Alert!"
          ),
        ]).catch((error) => {
          console.error("Error sending notifications:", error);
        });
      }
    }
  } catch (error) {
    console.error("Error checking and sending notifications:", error);
  }
}

// Export necessary functions
export { sendGmailNotification };
