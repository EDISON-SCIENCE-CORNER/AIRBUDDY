import webpush from "web-push";
import { PushSubscriptionModel } from "../models/push-subscription";
import { NotificationPayload, PushSubscription } from "../types/";

// Constants
const BATCH_SIZE = 10; // Process notifications in batches of 10
const RETRY_COUNT = 3;

export async function addSubscription(
  subscription: PushSubscription
): Promise<void> {
  try {
    await PushSubscriptionModel.findOneAndUpdate(
      { endpoint: subscription.endpoint },
      subscription,
      { upsert: true, new: true }
    );
  } catch (error) {
    console.error("Error adding push subscription:", error);
    throw new Error("Failed to add push subscription");
  }
}

export async function removeInvalidSubscription(
  endpoint: string
): Promise<void> {
  try {
    await PushSubscriptionModel.deleteOne({ endpoint });
  } catch (error) {
    console.error("Error removing invalid subscription:", error);
    throw new Error("Failed to remove invalid subscription");
  }
}

async function sendNotificationWithRetry(
  subscription: PushSubscription,
  payload: string,
  attempt = 1
): Promise<void> {
  try {
    await webpush.sendNotification(subscription, payload);
  } catch (error: any) {
    console.error(
      `Attempt ${attempt}/${RETRY_COUNT} - Error sending notification to:`,
      subscription.endpoint,
      error
    );

    // Remove invalid subscriptions
    if (error.statusCode === 404 || error.statusCode === 410) {
      await removeInvalidSubscription(subscription.endpoint);
      return;
    }

    // Retry with exponential backoff if not out of retries
    if (attempt < RETRY_COUNT) {
      const delay = Math.pow(2, attempt) * 1000;
      await new Promise((resolve) => setTimeout(resolve, delay));
      return sendNotificationWithRetry(subscription, payload, attempt + 1);
    }

    throw error;
  }
}

async function processBatch(
  subscriptions: PushSubscription[],
  payload: string
): Promise<void> {
  const promises = subscriptions.map((subscription) =>
    sendNotificationWithRetry(subscription, payload).catch((error) => {
      console.error("Failed to send notification:", error);
      return null;
    })
  );

  await Promise.all(promises);
}

export async function sendPushNotificationToAll(
  payload: NotificationPayload
): Promise<void> {
  try {
    const subscriptions = await PushSubscriptionModel.find();

    if (subscriptions.length === 0) {
      console.warn("No subscribers to send notifications to.");
      return;
    }

    const jsonPayload = JSON.stringify({
      title: payload.title || "Air Buddy Notification",
      body: payload.body || "You have a new notification.",
    });

    // Process subscriptions in batches
    for (let i = 0; i < subscriptions.length; i += BATCH_SIZE) {
      const batch = subscriptions.slice(i, i + BATCH_SIZE);
      await processBatch(batch, jsonPayload);
    }
  } catch (error) {
    console.error("Error in sendNotificationToAll:", error);
    throw new Error("Failed to send notifications to all subscribers");
  }
}

export async function sendWelcomeNotification(
  subscription: PushSubscription
): Promise<void> {
  const payload = JSON.stringify({
    title: "Welcome!",
    body: "You have successfully subscribed to notifications.",
    icon: "/icon-192x192.png",
  });

  try {
    await sendNotificationWithRetry(subscription, payload);
    console.log("Welcome notification sent successfully.");
  } catch (error) {
    console.error("Error sending welcome notification:", error);
    throw new Error("Failed to send welcome notification");
  }
}
