import { DocumentType } from "@typegoose/typegoose";
import { SensorHistory, SensorHistoryModel } from "../models/sensor-history";
// import { checkAndSendNotification } from "./notification.service";

export const getLatestData =
  async (): Promise<DocumentType<SensorHistory> | null> => {
    return await SensorHistoryModel.findOne().sort({ createdAt: -1 });
  };

export const getHistoryData = async (
  page: number = 1,
  limit: number = 20,
  period: string = "today"
): Promise<DocumentType<SensorHistory>[]> => {
  const skip = (page - 1) * limit;
  let dateFilter = {};

  // Create date filter based on period
  const now = new Date();
  switch (period) {
    case "today":
      dateFilter = {
        createdAt: {
          $gte: new Date(now.setHours(0, 0, 0, 0)),
          $lte: new Date(now.setHours(23, 59, 59, 999)),
        },
      };
      break;
    case "week":
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      dateFilter = {
        createdAt: {
          $gte: weekAgo,
          $lte: now,
        },
      };
      break;
    case "month":
      const monthAgo = new Date();
      monthAgo.setMonth(monthAgo.getMonth() - 1);
      dateFilter = {
        createdAt: {
          $gte: monthAgo,
          $lte: now,
        },
      };
      break;
    case "year":
      const yearAgo = new Date();
      yearAgo.setFullYear(yearAgo.getFullYear() - 1);
      dateFilter = {
        createdAt: {
          $gte: yearAgo,
          $lte: now,
        },
      };
      break;
    default:
      // No filter for 'all' or invalid periods
      break;
  }

  return await SensorHistoryModel.find(dateFilter)
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(limit);
};

export const update = async (
  data: SensorHistory
): Promise<DocumentType<SensorHistory>> => {
  const newData = new SensorHistoryModel(data);
  const savedData = await newData.save();

  // Check thresholds and send notifications if needed
  // await checkAndSendNotification(data);

  return savedData;
};
