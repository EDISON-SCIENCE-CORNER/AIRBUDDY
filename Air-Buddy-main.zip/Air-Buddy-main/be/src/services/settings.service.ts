import { DocumentType } from "@typegoose/typegoose";
import { Settings, SettingsModel } from "../models/settings";

export const getSettings = async (): Promise<DocumentType<Settings> | null> => {
  return await SettingsModel.findOne();
};

export const createSettings = async (
  settingsData: Settings
): Promise<DocumentType<Settings>> => {
  const settings = new SettingsModel(settingsData);
  return await settings.save();
};

export const updateSettings = async (
  settingsData: Settings
): Promise<DocumentType<Settings> | null> => {
  const settings = await SettingsModel.findOne();

  if (!settings) {
    return createSettings(settingsData);
  }

  Object.assign(settings, settingsData);
  return await settings.save();
};
