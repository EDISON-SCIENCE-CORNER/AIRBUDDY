import { DocumentType } from "@typegoose/typegoose";
import bcrypt from "bcrypt";
import gravatar from "gravatar";
import { User, UserModel } from "../models/user";
import { CreateUserDto, UpdateUserDto } from "../types/";

export const createUser = async (
  createUserDto: CreateUserDto
): Promise<DocumentType<User>> => {
  const { email, password } = createUserDto;

  const existingUser = await UserModel.findOne({ email });
  if (existingUser) {
    throw new Error("Email already in use");
  }

  const salt = await bcrypt.genSalt(10);
  const hashedPassword = await bcrypt.hash(password, salt);

  const profilePicUrl = gravatar.url(email, {
    s: "200",
    r: "pg",
    d: "identicon",
  });

  const newUser = new UserModel({
    ...createUserDto,
    password: hashedPassword,
    passwordSalt: salt,
    profilePicUrl,
  });

  return newUser.save();
};

export const findAllUsers = async (): Promise<DocumentType<User>[]> => {
  return UserModel.find()
    .sort({ createdAt: -1 })
    .select("-password -passwordSalt")
    .exec() as Promise<DocumentType<User>[]>;
};

export const findUserById = async (
  id: string
): Promise<DocumentType<User> | null> => {
  return (await UserModel.findById(id).select(
    "-password -passwordSalt"
  )) as DocumentType<User> | null;
};

export const findUserByEmail = async (
  email: string
): Promise<DocumentType<User> | null> => {
  return UserModel.findOne({ email }) as Promise<DocumentType<User> | null>;
};

export const updateUser = async (
  id: string,
  updateUserDto: UpdateUserDto
): Promise<DocumentType<User> | null> => {
  if (updateUserDto.password) {
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(updateUserDto.password, salt);
    updateUserDto.password = hashedPassword;
    // @ts-ignore - TypeScript doesn't know we have passwordSalt in our model
    updateUserDto.passwordSalt = salt;
  }

  return UserModel.findByIdAndUpdate(id, updateUserDto, { new: true }).select(
    "-password -passwordSalt"
  ) as Promise<DocumentType<User> | null>;
};

export const removeUser = async (id: string): Promise<{ message: string }> => {
  const deletedUser = await UserModel.findByIdAndDelete(id);
  if (!deletedUser) {
    return { message: "User not found" };
  }
  return { message: "User deleted successfully" };
};

export const verifyPassword = async (
  plainPassword: string,
  hashedPassword: string
): Promise<boolean> => {
  return bcrypt.compare(plainPassword, hashedPassword);
};
