import { Server } from "socket.io";
import { handleSensorHistorySocket } from "./sensor-history.socket";
export const setupSocketHandlers = (io: Server) => {
  io.on("connection", (socket) => {
    console.log("Client connected:", socket.id);

    handleSensorHistorySocket(io, socket);

    socket.on("disconnect", () => {
      console.log("Client disconnected:", socket.id);
    });
  });
};
