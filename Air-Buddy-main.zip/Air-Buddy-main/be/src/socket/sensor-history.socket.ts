import { Server, Socket } from "socket.io";
import * as sensorHistoryService from "../services/sensor-history.service";

export const handleSensorHistorySocket = (io: Server, socket: Socket) => {
  // Send latest sensor data when client connects
  sensorHistoryService.getLatestData().then((data) => {
    socket.emit("sensor:latest-data", data);
  });

  // Handle sensor data update requests from clients
  socket.on("sensor:update", async (sensorData) => {
    try {
      console.log("Received sensor data update:", sensorData);
      const updatedData = await sensorHistoryService.update(sensorData);
      // Broadcast the updated data to all connected clients
      io.emit("sensor:latest-data", updatedData);
    } catch (error) {
      socket.emit("sensor:error", {
        message: "Error updating sensor data",
        error,
      });
    }
  });

  // Handle client requesting latest data
  socket.on("sensor:get-latest", async () => {
    try {
      const data = await sensorHistoryService.getLatestData();
      socket.emit("sensor:latest-data", data);
    } catch (error) {
      socket.emit("sensor:error", {
        message: "Error fetching latest sensor data",
        error,
      });
    }
  });
};
