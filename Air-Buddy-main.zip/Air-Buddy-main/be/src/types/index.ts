export interface CreateUserDto {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  isAdmin?: boolean;
}

export interface UpdateUserDto {
  firstName?: string;
  lastName?: string;
  email?: string;
  password?: string;
  isAdmin?: boolean;
  isActive?: boolean;
}

export interface LoginDto {
  email: string;
  password: string;
}

export interface JwtPayload {
  userId: string;
  email: string;
  isAdmin: boolean;
}

export interface PushSubscription {
  endpoint: string;
  keys: {
    p256dh: string;
    auth: string;
  };
}

export interface NotificationPayload {
  title?: string;
  body?: string;
  url?: string;
}

// Re-export sensor types for convenience
export { getAllSensorTypes, getSensorConfig, SENSORS } from "./sensors";
export type { SensorConfig, SensorType } from "./sensors";
