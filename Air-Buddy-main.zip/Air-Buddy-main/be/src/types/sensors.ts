export type SensorType = "Temperature" | "Humidity" | "CO" | "NO2";

export interface SensorConfig {
  type: SensorType;
  label: string;
  unit: string;
  settingsMinKey: string;
  settingsMaxKey: string;
}

export const SENSORS: Record<SensorType, SensorConfig> = {
  Temperature: {
    type: "Temperature",
    label: "Temperature",
    unit: "°C",
    settingsMinKey: "minTemperature",
    settingsMaxKey: "maxTemperature",
  },
  Humidity: {
    type: "Humidity",
    label: "Humidity",
    unit: "%",
    settingsMinKey: "minHumidity",
    settingsMaxKey: "maxHumidity",
  },
  CO: {
    type: "CO",
    label: "CO",
    unit: "ppm",
    settingsMinKey: "minCO",
    settingsMaxKey: "maxCO",
  },
  NO2: {
    type: "NO2",
    label: "NO2",
    unit: "ppm",
    settingsMinKey: "minNO2",
    settingsMaxKey: "maxNO2",
  },
};

// Helper function to get all sensor types
export const getAllSensorTypes = (): SensorType[] => {
  return Object.keys(SENSORS) as SensorType[];
};

// Helper function to get sensor config by type
export const getSensorConfig = (type: SensorType): SensorConfig => {
  return SENSORS[type];
};
