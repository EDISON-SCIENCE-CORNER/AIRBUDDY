import SplashScreen from "@/components/splash-screen";
import { Router } from "@/router";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useState } from "react";
import { BrowserRouter } from "react-router-dom";
import NotificationListener from "./components/notification-listner";

const queryClient = new QueryClient();
function App() {
  const [showSplash, setShowSplash] = useState(true);

  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        {showSplash ? (
          <SplashScreen onComplete={() => setShowSplash(false)} />
        ) : (
          <Router />
        )}
        <NotificationListener />
      </BrowserRouter>
    </QueryClientProvider>
  );
}

export default App;
