import axios from "axios";
import type { SensorHistory, Settings, User } from "../types";

const apiClient = axios.create({
  baseURL: "/api",
});

apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      window.location.href = "/login";
    }
    return Promise.reject(error);
  }
);

export const createUser = async (userData: User): Promise<User> => {
  try {
    const response = await apiClient.post("/users", userData);
    return response.data;
  } catch (error: any) {
    throw error.response?.data || error.message;
  }
};

export const getUsers = async (): Promise<User[]> => {
  try {
    const response = await apiClient.get("/users");
    return response.data;
  } catch (error: any) {
    throw error.response?.data || error.message;
  }
};

export const getUserById = async (id: string): Promise<User> => {
  try {
    const response = await apiClient.get(`/users/${id}`);
    return response.data;
  } catch (error: any) {
    throw error.response?.data || error.message;
  }
};

export const getCurrentUser = async (): Promise<User> => {
  try {
    const response = await apiClient.get(`/users/me`);
    return response.data;
  } catch (error: any) {
    throw error.response?.data || error.message;
  }
};

export const updateUser = async (id: string, userData: User): Promise<User> => {
  try {
    const response = await apiClient.patch(`/users/${id}`, userData);
    return response.data;
  } catch (error: any) {
    throw error.response?.data || error.message;
  }
};

export const deleteUser = async (id: string): Promise<string> => {
  try {
    const response = await apiClient.delete(`/users/${id}`);
    return response.data;
  } catch (error: any) {
    throw error.response?.data || error.message;
  }
};

export const getHistory = async (
  page: number = 1,
  limit: number = 20,
  period: string = "today"
): Promise<SensorHistory[]> => {
  try {
    const response = await apiClient.get(
      `/sensor-history?page=${page}&limit=${limit}&period=${period}`
    );
    return response.data;
  } catch (error: any) {
    throw error.response?.data || error.message;
  }
};

export const login = async (email: string, password: string) => {
  try {
    const { data } = await apiClient.post("/auth/login", { email, password });
    return data;
  } catch (error: any) {
    throw error.response?.data || error.message;
  }
};

export const logout = async () => {
  try {
    await apiClient.post("/auth/logout");
  } catch (error: any) {
    throw error.response?.data || error.message;
  }
};

export const getSettings = async (): Promise<Settings> => {
  try {
    const response = await apiClient.get("/settings");
    return response.data;
  } catch (error: any) {
    throw error.response?.data || error.message;
  }
};

export const updateSettings = async (settings: Settings): Promise<Settings> => {
  try {
    const response = await apiClient.patch("/settings", settings);
    return response.data;
  } catch (error: any) {
    throw error.response?.data || error.message;
  }
};

export const getVapidPublicKey = async (): Promise<string> => {
  try {
    const response = await apiClient.get("notifications/vapid-public-key");
    return response.data;
  } catch (error: any) {
    throw error.response?.data || error.message;
  }
};

export const subscribeToNotifications = async (
  subscription: PushSubscription
): Promise<void> => {
  try {
    await apiClient.post("notifications/subscribe", subscription);
  } catch (error: any) {
    throw error.response?.data || error.message;
  }
};

export const generateApiKey = async (): Promise<{ key: string }> => {
  try {
    const response = await apiClient.post("/api-keys/generate");
    return response.data;
  } catch (error: any) {
    throw error.response?.data || error.message;
  }
};

export const getCurrentApiKey = async (): Promise<{ key: string } | null> => {
  try {
    const response = await apiClient.get("/api-keys/current");
    return response.data;
  } catch (error: any) {
    if (error.response?.status === 404) {
      return null;
    }
    throw error.response?.data || error.message;
  }
};

export const regenerateApiKey = async (): Promise<{ key: string }> => {
  try {
    const response = await apiClient.post("/api-keys/regenerate");
    return response.data;
  } catch (error: any) {
    throw error.response?.data || error.message;
  }
};

export const getLatestSensorData = async (): Promise<SensorHistory> => {
  try {
    const response = await apiClient.get("/sensor-history/latest");
    return response.data;
  } catch (error: any) {
    throw error.response?.data || error.message;
  }
};
