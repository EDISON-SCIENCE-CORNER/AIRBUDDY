import { generateApiKey, getCurrentApiKey, regenerateApiKey } from "@/api";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Key, RefreshCw } from "lucide-react";
import { useState } from "react";
import Button from "./ui/button";
import Card from "./ui/card";

export default function ApiKeyManager() {
  const [isKeyVisible, setIsKeyVisible] = useState(false);

  const apiKeyQuery = useQuery({
    queryKey: ["apiKey"],
    queryFn: getCurrentApiKey,
  });

  const generateKeyMutation = useMutation({
    mutationFn: generateApiKey,
    onSuccess: () => {
      apiKeyQuery.refetch();
    },
  });

  const regenerateKeyMutation = useMutation({
    mutationFn: regenerateApiKey,
    onSuccess: () => {
      apiKeyQuery.refetch();
    },
  });

  const handleGenerateKey = () => {
    generateKeyMutation.mutate();
  };

  const handleRegenerateKey = () => {
    if (
      confirm(
        "Are you sure you want to regenerate the API key? The old key will stop working."
      )
    ) {
      regenerateKeyMutation.mutate();
    }
  };

  const toggleKeyVisibility = () => {
    setIsKeyVisible(!isKeyVisible);
  };

  return (
    <Card>
      <div className="text-2xl font-bold text-black mb-6">
        API Key Management
      </div>
      <div className="space-y-6">
        {apiKeyQuery.data?.key ? (
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="flex-1">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  API Key
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type={isKeyVisible ? "text" : "password"}
                    value={apiKeyQuery.data.key}
                    readOnly
                    className="flex-1 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5"
                  />
                  <Button
                    variant="secondary"
                    onClick={toggleKeyVisibility}
                    className="flex items-center gap-2"
                  >
                    <Key className="w-4 h-4" />
                    {isKeyVisible ? "Hide" : "Show"}
                  </Button>
                </div>
              </div>
            </div>
            <Button
              variant="secondary"
              onClick={handleRegenerateKey}
              loading={regenerateKeyMutation.isPending}
              className="flex items-center gap-2"
            >
              <RefreshCw className="w-4 h-4" />
              Regenerate Key
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            <p className="text-gray-600">No API key has been generated yet.</p>
            <Button
              variant="primary"
              onClick={handleGenerateKey}
              loading={generateKeyMutation.isPending}
              className="flex items-center gap-2"
            >
              <Key className="w-4 h-4" />
              Generate API Key
            </Button>
          </div>
        )}
      </div>
    </Card>
  );
}
