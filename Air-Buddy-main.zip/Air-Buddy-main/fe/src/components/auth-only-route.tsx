import { Navigate } from "react-router-dom";

export const AuthOnlyRoute = ({ children }: { children: React.ReactNode }) => {
  const isLoggedIn = document.cookie.includes("isLoggedIn=true");

  if (isLoggedIn) {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
};
