import { AlertTriangle } from "lucide-react";

import type { User } from "@/types";
import Button from "./ui/button";
import Card from "./ui/card";

interface DeleteConfirmDialogProps {
  user: User;
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  loading?: boolean;
}

const DeleteConfirmDialog = ({
  user,
  isOpen,
  onClose,
  onConfirm,
  loading = false,
}: DeleteConfirmDialogProps) => {
  if (!isOpen) return null;

  const fullName = `${user.firstName} ${user.lastName}`.trim();

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <div className="p-6">
          {/* Header */}
          <div className="flex items-center gap-4 mb-6">
            <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center text-red-600">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-900">Delete User</h2>
              <p className="text-gray-600">This action cannot be undone</p>
            </div>
          </div>

          {/* Content */}
          <div className="mb-8">
            <p className="text-gray-600">
              Are you sure you want to delete the user{" "}
              <span className="font-medium text-gray-900">{fullName}</span>?
              This will permanently remove their account and all associated
              data.
            </p>
          </div>

          {/* Actions */}
          <div className="flex gap-3">
            <Button
              variant="ghost"
              onClick={onClose}
              disabled={loading}
              className="flex-1 !text-gray-600 border border-gray-200 hover:bg-gray-50"
            >
              Cancel
            </Button>
            <Button
              variant="primary"
              onClick={onConfirm}
              disabled={loading}
              className="flex-1 !bg-red-600 hover:!bg-red-700"
            >
              {loading ? "Deleting..." : "Confirm"}
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default DeleteConfirmDialog;
