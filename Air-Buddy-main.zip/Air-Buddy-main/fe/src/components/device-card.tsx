import { Loader2 } from "lucide-react";
import type { ReactNode } from "react";

interface DeviceCardProps {
  name: string;
  usage: number;
  icon: ReactNode;
  loading?: boolean;
  unit: string; // Optional unit for usage, e.g., "°C", "PPM", "%"
}

export default function DeviceCard({
  name,
  usage,
  icon,
  unit,
  loading = false,
}: DeviceCardProps) {
  return (
    <div
      className={`rounded-3xl p-6 text-black relative overflow-hidden bg-green-100 hover:bg-green-400 transition-all group`}
    >
      <div className="flex flex-col gap-2">
        <div className="w-10 h-10 flex items-center justify-center">{icon}</div>
        <p className="text-normal">{name}</p>
        <p className="text-2xl font-bold">
          {usage} <span className="text-sm font-normal">{unit}</span>
        </p>
      </div>
      {loading && (
        <div className="absolute bottom-4 right-4">
          <Loader2 className="animate-spin w-6 h-6" />
        </div>
      )}
    </div>
  );
}
