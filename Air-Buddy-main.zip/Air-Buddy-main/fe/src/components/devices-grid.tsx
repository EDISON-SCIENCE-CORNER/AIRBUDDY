import { useCurrentSensorData } from "@/hooks/useCurrentSensorData";
import { getAllSensorConfigs } from "@/constants/sensors";
import DeviceCard from "./device-card";
import Header from "./header";

export default function DevicesGrid() {
  const { currentData } = useCurrentSensorData();
  const lastUpdated = currentData?.updatedAt
    ? new Intl.DateTimeFormat("en-US", {
        dateStyle: "medium",
        timeStyle: "medium",
      }).format(new Date(currentData.updatedAt))
    : "";
  const values = currentData?.values || {};
  const sensors = getAllSensorConfigs();

  return (
    <>
      <Header />

      <div className="mb-6">
        <h2 className="text-4xl font-bold text-white">Parameters</h2>
        <p className="text-xs text-green-400">Last Updated on {lastUpdated}</p>
        <div className="grid grid-cols-2 gap-4 mt-6">
          {sensors.map((sensor) => {
            const Icon = sensor.icon;
            return (
              <DeviceCard
                key={sensor.key}
                name={sensor.displayName}
                usage={values[sensor.key] || 0}
                icon={<Icon className="w-10 h-10" />}
                unit={sensor.unit}
              />
            );
          })}
        </div>
      </div>
    </>
  );
}
