import type { User } from "@/types";
import Card from "./ui/card";
import UserForm from "./user-form";

interface EditUserDialogProps {
  user?: User | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (user: User) => void;
  loading?: boolean;
}

const EditUserDialog = ({
  user,
  isOpen,
  onClose,
  onSave,
  loading = false,
}: EditUserDialogProps) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center">
      <Card className="w-full max-w-md mx-4">
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-black">
            {user ? "Edit User" : "Create User"}
          </h2>
          <p className="text-gray-600">Please fill in the user details below</p>
        </div>
        <UserForm
          initialData={user || undefined}
          onSubmit={onSave}
          onClose={onClose}
          submitButtonText={user ? "Update" : "Create"}
          loading={loading}
        />
      </Card>
    </div>
  );
};

export default EditUserDialog;
