import { paths } from "@/router/routes";
import { BarChart3, Home, Settings, Users } from "lucide-react";
import { NavLink } from "react-router-dom";

const navigationItems = [
  { path: paths.HOME, icon: Home, label: "Home", active: false },
  {
    path: paths.STATISTICS,
    icon: BarChart3,
    label: "Statistics",
    active: true,
  },
  { path: paths.SETTINGS, icon: Settings, label: "Settings", active: false },
  { path: paths.USERS, icon: Users, label: "Users", active: false },
];

export default function FooterNavigation() {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-black/90 backdrop-blur-md border-t border-gray-800">
      <div className="flex items-center justify-around py-2 px-4 max-w-md mx-auto">
        {navigationItems.map(({ icon: Icon, path, label }) => (
          <NavLink
            key={path}
            to={`/${path}`}
            className={({ isActive }) =>
              `flex flex-col items-center gap-1 py-2 px-3 rounded-lg transition-colors w-[72px] h-[72px] justify-center ${
                isActive ? "bg-green-500/20 text-green-500" : "text-gray-400"
              }`
            }
          >
            <Icon className="w-6 h-6" />
            <span className="text-xs">{label}</span>
          </NavLink>
        ))}
      </div>
    </div>
  );
}
