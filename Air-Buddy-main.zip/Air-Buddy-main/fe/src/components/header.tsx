import { getCurrentUser } from "@/api";
import { useQuery } from "@tanstack/react-query";

export default function Header() {
  const currentUserQuery = useQuery({
    queryKey: ["currentUser"],
    queryFn: getCurrentUser,
  });

  const currentUser = currentUserQuery.data;
  if (!currentUser) {
    return null;
  }
  return (
    <div className="flex items-center gap-4 mb-12">
      <div className="relative h-14 w-14 rounded-full overflow-hidden border-2 border-green-600">
        <img
          src={
            currentUser.profilePicUrl ??
            "https://avatar.iran.liara.run/public/37"
          }
          alt="Profile"
          className="object-cover h-16 w-16"
        />
      </div>
      <div>
        <p className="text-xl font-medium">Good Morning 👋</p>
        <h1 className="text-3xl font-bold">
          {currentUser.firstName}{" "}
          <span className="font-normal text-green-300">
            {currentUser.lastName}
          </span>
        </h1>
      </div>
    </div>
  );
}
