import { getVapidPublicKey, subscribeToNotifications } from "@/api";
import { cn, urlBase64ToUint8Array } from "@/utils";
import { useCallback, useEffect, useState } from "react";

declare global {
  interface Window {
    swRegistration?: ServiceWorkerRegistration;
  }
}

function NotificationListener() {
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [vapidPublicKey, setVapidPublicKey] = useState("");

  const showTemporaryError = useCallback((message: string) => {
    setErrorMessage(message);
    setTimeout(() => {
      setErrorMessage(null);
    }, 2000);
  }, []);

  const initializeSubscriptionStatus = useCallback(async () => {
    if (!("serviceWorker" in navigator) || !window.swRegistration) {
      return;
    }
    try {
      const existingSubscription =
        await window.swRegistration.pushManager.getSubscription();
      setIsSubscribed(!!existingSubscription);
    } catch {
      showTemporaryError("Error checking notification status.");
    }
  }, [showTemporaryError]);

  const enableNotifications = useCallback(async () => {
    if (isSubscribed || !vapidPublicKey) {
      return;
    }

    setErrorMessage(null);

    try {
      const permissionResult = await Notification.requestPermission();
      if (permissionResult !== "granted") {
        throw new Error("Notification permission denied.");
      }

      if (!window.swRegistration) {
        throw new Error("Service worker not found.");
      }

      const applicationServerKey = urlBase64ToUint8Array(vapidPublicKey);
      const subscription = await window.swRegistration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: applicationServerKey,
      });

      await subscribeToNotifications(subscription);
      setIsSubscribed(true);
    } catch (error: any) {
      showTemporaryError(error.message);
      setIsSubscribed(false);
    }
  }, [isSubscribed, vapidPublicKey, showTemporaryError]);

  useEffect(() => {
    getVapidPublicKey()
      .then((key) => {
        setVapidPublicKey(key);
        initializeSubscriptionStatus();
      })
      .catch(() => {
        showTemporaryError("Could not fetch VAPID key from server.");
      });
  }, [initializeSubscriptionStatus, showTemporaryError]);

  useEffect(() => {
    if (!vapidPublicKey) {
      return;
    }
    enableNotifications();
  }, [vapidPublicKey, enableNotifications]);

  return (
    <div
      className={cn(
        "fixed bottom-4 left-1/2 -translate-x-1/2 transition-all duration-300 transform",
        errorMessage
          ? "translate-y-0 opacity-100"
          : "translate-y-full opacity-0"
      )}
    >
      {errorMessage && (
        <div className="bg-red-500/10 border border-red-500/50 text-red-500 px-4 py-3 rounded-lg shadow-lg">
          {errorMessage}
        </div>
      )}
    </div>
  );
}

export default NotificationListener;
