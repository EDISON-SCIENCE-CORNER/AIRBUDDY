"use client";

import { Calendar, ChevronDown } from "lucide-react";
import { useState } from "react";

interface PeriodSelectorProps {
  selectedPeriod: string;
  onPeriodChange: (period: string) => void;
}

const periods = [
  { value: "today", label: "Today" },
  { value: "week", label: "Last 7 Days" },
  { value: "month", label: "Last 30 Days" },
  { value: "3months", label: "Last 3 Months" },
];

export default function PeriodSelector({
  selectedPeriod,
  onPeriodChange,
}: PeriodSelectorProps) {
  const [isOpen, setIsOpen] = useState(false);

  const selectedLabel =
    periods.find((p) => p.value === selectedPeriod)?.label || "Today";

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl px-4 py-3 text-white hover:bg-white/20 transition-colors"
      >
        <Calendar className="w-5 h-5" />
        <span className="font-medium">{selectedLabel}</span>
        <ChevronDown
          className={`w-4 h-4 transition-transform ${
            isOpen ? "rotate-180" : ""
          }`}
        />
      </button>

      {isOpen && (
        <div className="absolute top-full right-0 mt-2 bg-white rounded-2xl shadow-xl border border-gray-200 py-2 min-w-[200px] z-10">
          {periods.map((period) => (
            <button
              key={period.value}
              onClick={() => {
                onPeriodChange(period.value);
                setIsOpen(false);
              }}
              className={`w-full text-left px-4 py-3 hover:bg-gray-50 transition-colors ${
                selectedPeriod === period.value
                  ? "bg-green-50 text-green-700 font-medium"
                  : "text-gray-700"
              }`}
            >
              {period.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
