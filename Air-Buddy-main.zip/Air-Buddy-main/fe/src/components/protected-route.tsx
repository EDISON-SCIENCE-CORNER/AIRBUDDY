import { paths } from "@/router/routes";
import { Navigate } from "react-router-dom";

export const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const isLoggedIn = document.cookie.includes("isLoggedIn=true");

  if (!isLoggedIn) {
    return <Navigate to={`/${paths.LOGIN}`} />;
  }

  return <>{children}</>;
};
