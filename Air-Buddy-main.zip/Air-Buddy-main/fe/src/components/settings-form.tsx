import { getAllSensorConfigs } from "@/constants/sensors";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useEffect, useMemo } from "react";
import { useForm } from "react-hook-form";
import { getSettings, updateSettings } from "../api";

import Button from "./ui/button";
import Card from "./ui/card";
import Input from "./ui/input";

export default function SettingsForm() {
  const settingsQuery = useQuery({
    queryKey: ["settings"],
    queryFn: getSettings,
  });

  const settingsMutation = useMutation({
    mutationFn: updateSettings,
  });

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm<Record<string, number>>({
    mode: "onTouched",
  });

  // Generate form fields from sensor config
  const formFields = useMemo(() => {
    const fields: Array<{
      label: string;
      type: string;
      id: string;
      placeholder: string;
      validation: {
        required: string;
        min: { value: number; message: string };
        max: { value: number; message: string };
        validate: { isNumber: (value: number) => string | boolean };
      };
    }> = [];

    getAllSensorConfigs().forEach((sensor) => {
      const min = sensor.defaultMin ?? 0;
      const max = sensor.defaultMax ?? 100;
      const displayName = sensor.displayName.toLowerCase();

      // Minimum field
      fields.push({
        label: `Minimum ${sensor.displayName}`,
        type: "number",
        id: sensor.settingsMinKey,
        placeholder: `Enter minimum ${displayName} (${min}-${max})`,
        validation: {
          required: `Minimum ${displayName} is required`,
          min: {
            value: min,
            message: `${sensor.displayName} must be at least ${min}`,
          },
          max: {
            value: max,
            message: `${sensor.displayName} cannot exceed ${max}`,
          },
          validate: {
            isNumber: (value: number) =>
              !isNaN(value) || `Please enter a valid ${displayName} number`,
          },
        },
      });

      // Maximum field
      fields.push({
        label: `Maximum ${sensor.displayName}`,
        type: "number",
        id: sensor.settingsMaxKey,
        placeholder: `Enter maximum ${displayName} (${min}-${max})`,
        validation: {
          required: `Maximum ${displayName} is required`,
          min: {
            value: min,
            message: `${sensor.displayName} must be at least ${min}`,
          },
          max: {
            value: max,
            message: `${sensor.displayName} cannot exceed ${max}`,
          },
          validate: {
            isNumber: (value: number) =>
              !isNaN(value) || `Please enter a valid ${displayName} number`,
          },
        },
      });
    });

    return fields;
  }, []);

  const onSubmit = async (data: Record<string, number>) => {
    try {
      await settingsMutation.mutateAsync({ settings: data });
    } catch (error) {
      console.error(error);
    }
  };

  const loading = settingsMutation.isPending;
  const dataLoading = settingsQuery.isLoading;

  useEffect(() => {
    if (settingsQuery.data?.settings) {
      Object.entries(settingsQuery.data.settings).forEach(([key, value]) => {
        setValue(key, value);
      });
    }
  }, [settingsQuery.data, setValue]);

  return (
    <Card>
      <div className="text-2xl font-bold text-black mb-6">
        Device Parameters
      </div>
      <form className="space-y-6" onSubmit={handleSubmit(onSubmit)}>
        {formFields.map(({ label, id, placeholder, validation, type }) => (
          <Input
            key={id}
            type={type}
            label={label}
            placeholder={placeholder}
            error={errors[id]?.message as string}
            {...register(id, {
              ...(type === "number" && { valueAsNumber: true }),
              ...validation,
            })}
          />
        ))}

        <Button
          type="submit"
          disabled={loading || dataLoading}
          loading={loading}
          className="w-full"
        >
          Save Changes
        </Button>
      </form>
    </Card>
  );
}
