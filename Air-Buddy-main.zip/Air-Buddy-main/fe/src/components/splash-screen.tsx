"use client";

import { HeartPlus, Loader2 } from "lucide-react";
import { useEffect, useState } from "react";

interface SplashScreenProps {
  onComplete?: () => void;
  duration?: number;
}

const loadingSteps = [
  "Initializing...",
  "Loading records...",
  "Checking health data...",
  "Setting up parameters...",
  "Almost ready...",
];
export default function SplashScreen({
  onComplete,
  duration = import.meta.env.PROD ? 3000 : 300,
}: SplashScreenProps) {
  const [progress, setProgress] = useState(0);
  const [showContent, setShowContent] = useState(false);
  const [loadingText, setLoadingText] = useState(loadingSteps[0]);

  useEffect(() => {
    // Show content with animation
    const contentTimer = setTimeout(() => {
      setShowContent(true);
    }, 200);

    // Progress bar animation
    const progressInterval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          return 100;
        }
        return prev + 2;
      });
    }, duration / 50);

    // Loading text updates
    const textInterval = setInterval(() => {
      setLoadingText((prev) => {
        const currentIndex = loadingSteps.indexOf(prev);
        const nextIndex = (currentIndex + 1) % loadingSteps.length;
        return loadingSteps[nextIndex];
      });
    }, duration / loadingSteps.length);

    // Complete splash screen
    const completeTimer = setTimeout(() => {
      if (onComplete) {
        onComplete();
      }
    }, duration);

    return () => {
      clearTimeout(contentTimer);
      clearTimeout(completeTimer);
      clearInterval(progressInterval);
      clearInterval(textInterval);
    };
  }, [duration, onComplete]);

  return (
    <div className="min-h-screen w-full bg-gradient-to-b from-black via-black to-green-900 flex flex-col items-center justify-center p-6 relative overflow-hidden">
      {/* Background Animation Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-32 h-32 bg-green-500/10 rounded-full blur-xl animate-pulse"></div>
        <div className="absolute top-3/4 right-1/4 w-24 h-24 bg-green-400/10 rounded-full blur-xl animate-pulse delay-1000"></div>
        <div className="absolute bottom-1/4 left-1/3 w-20 h-20 bg-green-500/5 rounded-full blur-xl animate-pulse delay-2000"></div>
      </div>

      {/* Main Content */}
      <div
        className={`
          flex flex-col items-center justify-center space-y-8 z-10 transition-all duration-1000 transform
          ${
            showContent
              ? "opacity-100 translate-y-0 scale-100"
              : "opacity-0 translate-y-8 scale-95"
          }
        `}
      >
        {/* App Logo */}
        <div className="relative">
          {/* Glow effect */}
          <div className="absolute inset-0 w-32 h-32 bg-gradient-to-r from-green-500 to-green-400 rounded-full blur-2xl opacity-30 animate-pulse"></div>

          {/* Logo container */}
          <div className="relative w-32 h-32 bg-gradient-to-r from-green-500 to-green-400 rounded-full flex items-center justify-center shadow-2xl transform hover:scale-105 transition-transform duration-300">
            <HeartPlus className="w-16 h-16 text-white animate-pulse" />
          </div>
        </div>

        {/* App Name */}
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold text-white tracking-wider">
            Air Buddy
          </h1>
          <p className="text-lg text-gray-300 font-light tracking-wide">
            Buddy for Monitoring Air Quality
          </p>
        </div>

        {/* Loading Section */}
        <div className="w-full max-w-sm space-y-6 mt-12">
          {/* Progress Bar */}
          <div className="relative">
            <div className="w-full h-2 bg-gray-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-green-500 to-green-400 rounded-full transition-all duration-300 ease-out relative"
                style={{ width: `${progress}%` }}
              >
                {/* Shimmer effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-shimmer"></div>
              </div>
            </div>
            <div className="text-right mt-2">
              <span className="text-sm text-gray-400">{progress}%</span>
            </div>
          </div>

          {/* Loading Text */}
          <div className="flex items-center justify-center space-x-3">
            <Loader2 className="w-5 h-5 text-green-500 animate-spin" />
            <span className="text-gray-300 text-lg font-medium">
              {loadingText}
            </span>
          </div>
        </div>

        {/* Version Info */}
        <div className="text-center">
          <p className="text-gray-500 text-sm">Version 1.0.0</p>
          <p className="text-gray-600 text-xs mt-1">
            © 2024 Air Buddy. All rights reserved.
          </p>
        </div>
      </div>

      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/3 left-1/6 text-green-500/20 animate-float">
          <HeartPlus className="w-8 h-8" />
        </div>
        <div className="absolute top-1/2 right-1/6 text-green-400/20 animate-float-delayed">
          <HeartPlus className="w-6 h-6" />
        </div>
        <div className="absolute bottom-1/3 left-1/4 text-green-500/15 animate-float-slow">
          <HeartPlus className="w-10 h-10" />
        </div>
      </div>
    </div>
  );
}
