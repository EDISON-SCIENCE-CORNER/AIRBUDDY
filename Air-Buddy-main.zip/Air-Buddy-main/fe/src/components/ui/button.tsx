"use client";

import type React from "react";

import { forwardRef } from "react";

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "ghost";
  size?: "sm" | "md" | "lg";
  loading?: boolean;
}

const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      className = "",
      variant = "primary",
      size = "md",
      loading = false,
      children,
      disabled,
      ...props
    },
    ref
  ) => {
    const baseClasses =
      "font-semibold rounded-2xl transition-all duration-200 flex items-center justify-center gap-2";

    const variants = {
      primary:
        "bg-gradient-to-r from-green-500 to-green-400 text-white hover:from-green-600 hover:to-green-500 active:scale-95",
      secondary:
        "bg-white text-black border-2 border-gray-200 hover:border-green-500 hover:bg-gray-50",
      ghost: "bg-transparent text-white hover:bg-white/10",
    };

    const sizes = {
      sm: "px-4 py-2 text-sm",
      md: "px-6 py-3 text-base",
      lg: "px-8 py-4 text-lg",
    };

    const isDisabled = disabled || loading;

    return (
      <button
        className={`
          ${baseClasses}
          ${variants[variant]}
          ${sizes[size]}
          ${isDisabled ? "opacity-50 cursor-not-allowed" : ""}
          ${className}
        `}
        disabled={isDisabled}
        ref={ref}
        {...props}
      >
        {loading && (
          <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
        )}
        {children}
      </button>
    );
  }
);

Button.displayName = "Button";

export default Button;
