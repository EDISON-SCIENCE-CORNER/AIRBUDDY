"use client";

import type React from "react";

import { forwardRef } from "react";

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
}

const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ className = "", label, error, type = "text", ...props }, ref) => {
    return (
      <div className="w-full">
        {label && (
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {label}
          </label>
        )}
        <input
          type={type}
          className={`
            w-full px-4 py-3 rounded-2xl border-2 border-gray-200 
            focus:border-green-500 focus:outline-none focus:ring-0
            bg-white text-black placeholder-gray-400
            transition-colors duration-200
            ${error ? "border-red-400 focus:border-red-400" : ""}
            ${className}
          `}
          ref={ref}
          {...props}
        />
        {error && <p className="mt-1 text-sm text-red-500">{error}</p>}
      </div>
    );
  }
);

Input.displayName = "Input";

export default Input;
