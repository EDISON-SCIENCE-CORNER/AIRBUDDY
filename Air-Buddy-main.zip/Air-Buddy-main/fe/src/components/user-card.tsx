"use client";

import Button from "@/components/ui/button";
import type { User } from "@/types";
import { Edit, Shield, Trash2, User as UserIcon } from "lucide-react";

interface UserCardProps {
  user: User;
  onEdit: (user: User) => void;
  onDelete: (user: User) => void;
}

export default function UserCard({ user, onEdit, onDelete }: UserCardProps) {
  const fullName = `${user.firstName} ${user.lastName}`.trim();

  return (
    <div className="bg-white rounded-3xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
      {/* Header with Avatar and Status */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-4">
          <div className="relative">
            <img
              src={user.profilePicUrl || "/placeholder.svg"}
              alt={fullName}
              className="w-16 h-16 rounded-full object-cover border-4 border-gray-100"
            />
            {!user.isActive && (
              <div className="absolute -top-1 -right-1 w-6 h-6 bg-red-500 rounded-full border-2 border-white"></div>
            )}
          </div>
          <div className="flex-1">
            <h3 className="text-xl font-bold text-black">
              {fullName || "New User"}
            </h3>
            {user.isAdmin && (
              <div className="flex items-center gap-1 max-w-fit bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs font-medium">
                <Shield className="w-3 h-3" />
                Admin
              </div>
            )}
          </div>
        </div>
      </div>

      {/* User Info */}
      <div className="space-y-2 mb-6">
        <div className="flex items-center gap-2 text-gray-600">
          <UserIcon className="w-4 h-4" />
          <span className="text-sm">{user.email}</span>
        </div>
        <div className="flex items-center gap-2">
          <div
            className={`w-3 h-3 rounded-full ${
              user.isActive ? "bg-green-500" : "bg-red-500"
            }`}
          ></div>
          <span
            className={`text-sm font-medium ${
              user.isActive ? "text-green-600" : "text-red-600"
            }`}
          >
            {user.isActive ? "Active" : "Inactive"}
          </span>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex gap-2">
        <Button
          onClick={() => onEdit(user)}
          variant="secondary"
          size="sm"
          className="flex-1 flex items-center justify-center gap-2"
        >
          <Edit className="w-4 h-4" />
          Edit
        </Button>
        <Button
          onClick={() => onDelete(user)}
          variant="ghost"
          size="sm"
          className="flex items-center justify-center gap-2 !text-red-600 hover:bg-red-50 border border-red-200"
        >
          <Trash2 className="w-4 h-4" />
          Delete
        </Button>
      </div>
    </div>
  );
}
