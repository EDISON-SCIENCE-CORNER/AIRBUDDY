import type { User } from "@/types";

import { useEffect } from "react";
import { useForm } from "react-hook-form";
import Button from "./ui/button";

import Input from "./ui/input";

interface UserFormProps {
  initialData?: User;
  onSubmit: (data: User) => void;
  onClose: () => void;

  submitButtonText: string;
  loading: boolean;
}

const UserForm = ({
  initialData,
  onSubmit,
  onClose,

  submitButtonText,
  loading = false,
}: UserFormProps) => {
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm<User>({
    mode: "onTouched",
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      password: "",
      isAdmin: false,
    },
  });

  useEffect(() => {
    if (initialData) {
      setValue("firstName", initialData.firstName);
      setValue("lastName", initialData.lastName);
      setValue("email", initialData.email);
      setValue("password", initialData.password);
      setValue("isAdmin", initialData.isAdmin);
    }
  }, [initialData, setValue]);

  const handleFormSubmit = async (data: User) => {
    try {
      onSubmit(data);
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-6">
      <Input
        label="First Name"
        error={errors.firstName?.message}
        {...register("firstName", {
          required: "First name is required",
          validate: (value) => !!value.trim() || "First name is required",
        })}
      />

      <Input
        label="Last Name"
        error={errors.lastName?.message}
        {...register("lastName", {
          required: "Last name is required",
          validate: (value) => !!value.trim() || "Last name is required",
        })}
      />

      <Input
        type="email"
        label="Email Address"
        error={errors.email?.message}
        {...register("email", {
          required: "Email is required",
          pattern: {
            value: /\S+@\S+\.\S+/,
            message: "Email is invalid",
          },
        })}
      />

      <Input
        type="password"
        label={`Password ${initialData ? "(Leave blank to keep current)" : ""}`}
        error={errors.password?.message}
        {...register("password", {
          required: !initialData ? "Password is required" : false,
          minLength: !initialData
            ? {
                value: 8,
                message: "Password must be at least 8 characters",
              }
            : undefined,
        })}
      />

      <div className="flex items-center space-x-2">
        <input
          type="checkbox"
          id="isAdmin"
          className="w-4 h-4 text-green-500 border-gray-300 rounded focus:ring-green-500"
          {...register("isAdmin")}
        />
        <label htmlFor="isAdmin" className="text-gray-700">
          Admin User
        </label>
      </div>

      <div className="flex justify-end space-x-3 pt-4">
        <Button
          variant="ghost"
          onClick={onClose}
          className="!text-gray-600 border border-gray-200 hover:bg-gray-50"
        >
          Cancel
        </Button>
        <Button
          type="submit"
          variant="primary"
          loading={loading}
          disabled={loading || Object.keys(errors).length > 0}
        >
          {submitButtonText}
        </Button>
      </div>
    </form>
  );
};

export default UserForm;
