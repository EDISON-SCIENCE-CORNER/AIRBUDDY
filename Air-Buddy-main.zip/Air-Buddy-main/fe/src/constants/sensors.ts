import { AlertTriangle, Droplet, Thermometer, Wind } from "lucide-react";
import type { ComponentType } from "react";

export type SensorType = "Temperature" | "Humidity" | "CO" | "NO2";

export interface SensorConfig {
  key: SensorType;
  displayName: string;
  unit: string;
  icon: ComponentType<{ className?: string }>;
  chartDataKey: string; // For consistent casing in charts
  settingsMinKey: string; // e.g., "minTemperature"
  settingsMaxKey: string; // e.g., "maxTemperature"
  // For stat cards and chart titles
  statTitle?: string;
  chartTitle?: string;
  // For validation ranges (optional, can be overridden)
  defaultMin?: number;
  defaultMax?: number;
}

export const SENSORS: Record<SensorType, SensorConfig> = {
  Temperature: {
    key: "Temperature",
    displayName: "Temperature",
    unit: "°C",
    icon: Thermometer,
    chartDataKey: "temperature",
    settingsMinKey: "minTemperature",
    settingsMaxKey: "maxTemperature",
    statTitle: "Room Temperature",
    chartTitle: "Room Temperature",
    defaultMin: 0,
    defaultMax: 100,
  },
  Humidity: {
    key: "Humidity",
    displayName: "Humidity",
    unit: "%",
    icon: Droplet,
    chartDataKey: "humidity",
    settingsMinKey: "minHumidity",
    settingsMaxKey: "maxHumidity",
    statTitle: "Humidity",
    chartTitle: "Humidity",
    defaultMin: 0,
    defaultMax: 100,
  },
  CO: {
    key: "CO",
    displayName: "CO",
    unit: "ppm",
    icon: AlertTriangle,
    chartDataKey: "CO",
    settingsMinKey: "minCO",
    settingsMaxKey: "maxCO",
    statTitle: "CO Level",
    chartTitle: "CO (Carbon Monoxide)",
    defaultMin: 0,
    defaultMax: 1000,
  },
  NO2: {
    key: "NO2",
    displayName: "NO2",
    unit: "ppm",
    icon: Wind,
    chartDataKey: "NO2",
    settingsMinKey: "minNO2",
    settingsMaxKey: "maxNO2",
    statTitle: "NO2 Level",
    chartTitle: "NO2 (Nitrogen Dioxide)",
    defaultMin: 0,
    defaultMax: 1000,
  },
};

// Helper function to get all sensor types
export const getAllSensorTypes = (): SensorType[] => {
  return Object.keys(SENSORS) as SensorType[];
};

// Helper function to get sensor config by type
export const getSensorConfig = (type: SensorType): SensorConfig => {
  return SENSORS[type];
};

// Helper function to get all sensor configs as array
export const getAllSensorConfigs = (): SensorConfig[] => {
  return Object.values(SENSORS);
};

// Helper function to map sensor values to chart data format
export const mapSensorValuesToChartData = (
  values: Record<string, number>
): Record<string, number> => {
  const chartData: Record<string, number> = {};
  getAllSensorConfigs().forEach((sensor) => {
    const value = values[sensor.key];
    if (value !== undefined) {
      chartData[sensor.chartDataKey] = value;
    }
  });
  return chartData;
};
