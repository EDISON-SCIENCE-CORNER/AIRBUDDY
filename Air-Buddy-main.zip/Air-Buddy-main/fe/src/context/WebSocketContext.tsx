import { createContext } from "react";
import { Socket } from "socket.io-client";

interface WebSocketContextType {
  socket: Socket | null;
  subscribe: (event: string, callback: (data: any) => void) => void;
  unsubscribe: (event: string) => void;
  isConnected: boolean;
}

export const WebSocketContext = createContext<WebSocketContextType | null>(
  null
);
