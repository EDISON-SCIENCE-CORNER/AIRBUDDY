import { getLatestSensorData } from "@/api";
import { type SensorHistory } from "@/types";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect } from "react";
import { useWebSocket } from "./useWebSocket";

const EVENTS = {
  SENSOR_DATA: "sensor:latest-data",
};

const QUERY_KEY = ["sensor-data", "latest"];

export const useCurrentSensorData = () => {
  const { subscribe, unsubscribe, isConnected } = useWebSocket()!;
  const queryClient = useQueryClient();

  const { data: currentData } = useQuery({
    queryKey: QUERY_KEY,
    queryFn: getLatestSensorData,
  });

  // Subscribe to real-time updates
  useEffect(() => {
    const handleSensorUpdate = (data: SensorHistory) => {
      queryClient.setQueryData(QUERY_KEY, data);
    };

    subscribe(EVENTS.SENSOR_DATA, handleSensorUpdate);

    return () => {
      unsubscribe(EVENTS.SENSOR_DATA);
    };
  }, [isConnected, queryClient, subscribe, unsubscribe]);

  return {
    currentData,
  };
};
