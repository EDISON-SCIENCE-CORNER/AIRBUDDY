import FooterNavigation from "@/components/footer-navigation";
import { Outlet } from "react-router-dom";

export const Home = () => {
  return (
    <div className="page !block">
      <Outlet />
      <FooterNavigation />
    </div>
  );
};
