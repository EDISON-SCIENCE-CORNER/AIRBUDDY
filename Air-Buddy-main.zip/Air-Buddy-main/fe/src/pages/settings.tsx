import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { LogOut } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { logout } from "../api";
import ApiKeyManager from "../components/api-key-manager";
import SettingsForm from "../components/settings-form";

const queryClient = new QueryClient();

export function Settings() {
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate("/login");
  };

  return (
    <QueryClientProvider client={queryClient}>
      <div className="container mx-auto p-4 relative">
        <button
          onClick={handleLogout}
          className="absolute right-6 top-5 p-2 rounded-full hover:bg-gray-700 transition-colors"
          title="Logout"
        >
          <LogOut className="w-6 h-6  text-red-500" />
        </button>
        <h1 className="text-2xl font-bold mb-4">Settings</h1>
        <div className="space-y-6">
          <ApiKeyManager />
          <SettingsForm />
        </div>
      </div>
    </QueryClientProvider>
  );
}
