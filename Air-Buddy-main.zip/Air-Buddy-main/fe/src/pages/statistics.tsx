"use client";

import { getHistory } from "@/api";
import ChartCard from "@/components/chart-card";
import PeriodSelector from "@/components/period-selector";
import StatCard from "@/components/stat-card";
import { getAllSensorConfigs, type SensorType } from "@/constants/sensors";
import type { SensorHistory } from "@/types";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";

export const Statistics = () => {
  const [selectedPeriod, setSelectedPeriod] = useState("today");

  const {
    data = [],
    isLoading,
    error,
  } = useQuery<SensorHistory[]>({
    queryKey: ["sensorHistory", selectedPeriod],
    queryFn: () => getHistory(1, 100, selectedPeriod), // Fetch records based on period
  });

  // Calculate averages for stat cards using centralized sensor config
  const averages = useMemo(() => {
    const avgs: Record<SensorType, number> = {} as Record<SensorType, number>;
    getAllSensorConfigs().forEach((sensor) => {
      const sum = data.reduce((acc, d) => acc + (d.values[sensor.key] || 0), 0);
      avgs[sensor.key] = data.length > 0 ? sum / data.length : 0;
    });
    return avgs;
  }, [data]);

  // Format data for charts using centralized sensor config
  const chartData = useMemo(() => {
    return data.map((item) => {
      const chartDataPoint: { time: string; [key: string]: any } = {
        time: new Date(item.createdAt).toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
          ...(selectedPeriod !== "today" && {
            month: "short",
            day: "numeric",
          }),
        }),
      };

      // Map all sensor values to chart data format
      getAllSensorConfigs().forEach((sensor) => {
        const value = item.values[sensor.key];
        if (value !== undefined) {
          // Use appropriate decimal places based on unit
          const decimalPlaces =
            sensor.unit === "°C" ||
            sensor.unit === "%" ||
            sensor.unit === "mg/L"
              ? 1
              : 0;
          chartDataPoint[sensor.chartDataKey] = Number(
            value.toFixed(decimalPlaces)
          );
        } else {
          chartDataPoint[sensor.chartDataKey] = 0;
        }
      });

      return chartDataPoint;
    });
  }, [data, selectedPeriod]);

  if (isLoading) {
    return (
      <div className="min-h-screen w-full bg-gradient-to-b from-black via-black to-green-900 text-white p-6 flex items-center justify-center">
        <div className="text-xl">Loading sensor data...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen w-full bg-gradient-to-b from-black via-black to-green-900 text-white p-6 flex items-center justify-center">
        <div className="text-xl text-red-500">
          Error loading sensor data. Please try again later.
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen w-full bg-gradient-to-b from-black via-black to-green-900 text-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold mb-2">Analytics</h1>
            <p className="text-gray-400">Monitor air quality over time</p>
          </div>
          <PeriodSelector
            selectedPeriod={selectedPeriod}
            onPeriodChange={setSelectedPeriod}
          />
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {getAllSensorConfigs()
            .slice(0, 4)
            .map((sensor) => {
              const Icon = sensor.icon;
              const avg = averages[sensor.key];
              const decimalPlaces =
                sensor.unit === "°C" ||
                sensor.unit === "%" ||
                sensor.unit === "mg/L"
                  ? 1
                  : 0;
              const value = `${avg.toFixed(decimalPlaces)}${
                sensor.unit === "bpm"
                  ? " BPM"
                  : sensor.unit === "ppb"
                  ? ""
                  : sensor.unit
              }`;

              // Color gradients for different sensors
              const colors: Record<SensorType, string> = {
                Temperature: "bg-gradient-to-r from-red-500 to-orange-500",
                Humidity: "bg-gradient-to-r from-blue-500 to-cyan-500",
                CO: "bg-gradient-to-r from-orange-500 to-red-500",
                NO2: "bg-gradient-to-r from-yellow-500 to-orange-500",
              };

              return (
                <StatCard
                  key={sensor.key}
                  title={sensor.statTitle || sensor.displayName}
                  value={value}
                  icon={<Icon className="w-6 h-6" />}
                  trend="+0.0%"
                  color={colors[sensor.key]}
                />
              );
            })}
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {getAllSensorConfigs().map((sensor) => {
            const Icon = sensor.icon;
            // Chart colors for different sensors
            const colors: Record<SensorType, string> = {
              Temperature: "#ef4444",
              Humidity: "#3b82f6",
              CO: "#f59e0b",
              NO2: "#eab308",
            };
            // Chart types for different sensors
            const chartTypes: Record<SensorType, "line" | "area" | "bar"> = {
              Temperature: "line",
              Humidity: "area",
              CO: "line",
              NO2: "bar",
            };

            return (
              <ChartCard
                key={sensor.key}
                title={sensor.chartTitle || sensor.displayName}
                data={chartData}
                dataKey={sensor.chartDataKey}
                unit={
                  sensor.unit === "bpm"
                    ? "BPM"
                    : sensor.unit === "ppb"
                    ? "score"
                    : sensor.unit
                }
                color={colors[sensor.key]}
                chartType={chartTypes[sensor.key]}
                icon={<Icon className="w-5 h-5" />}
              />
            );
          })}
        </div>
      </div>
    </div>
  );
};
