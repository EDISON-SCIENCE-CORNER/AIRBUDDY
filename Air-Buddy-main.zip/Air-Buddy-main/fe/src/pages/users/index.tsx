import { createUser, deleteUser, getUsers, updateUser } from "@/api";
import DeleteConfirmDialog from "@/components/delete-confirm-dialog";
import EditUserDialog from "@/components/edit-user-dialog";
import Button from "@/components/ui/button";
import UserCard from "@/components/user-card";
import type { User } from "@/types";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Plus } from "lucide-react";
import { useState } from "react";

export const Users = () => {
  const usersQuery = useQuery({
    queryKey: ["users"],
    queryFn: getUsers,
  });

  const createUserMutation = useMutation({
    mutationFn: createUser,
    onSuccess: () => {
      usersQuery.refetch();
      setShowEditDialog(false);
      setEditingUser(null);
    },
  });

  const updateUserMutation = useMutation({
    mutationFn: ({ id, userData }: { id: string; userData: User }) =>
      updateUser(id, userData),
    onSuccess: () => {
      usersQuery.refetch();
      setShowEditDialog(false);
      setEditingUser(null);
    },
  });

  const deleteUserMutation = useMutation({
    mutationFn: (id: string) => deleteUser(id),
    onSuccess: () => {
      usersQuery.refetch();
      setShowDeleteDialog(false);
      setDeletingUser(null);
    },
  });

  const users: User[] = usersQuery.data || ([] as User[]);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [deletingUser, setDeletingUser] = useState<User | null>(null);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);

  const handleEditUser = (user: User) => {
    setEditingUser(user);
    setShowEditDialog(true);
  };

  const handleDeleteUser = (user: User) => {
    setDeletingUser(user);
    setShowDeleteDialog(true);
  };

  const handleSaveUser = async (userData: User) => {
    if (editingUser) {
      updateUserMutation.mutate({ id: editingUser.id, userData });
    } else {
      createUserMutation.mutate(userData);
    }
  };

  const handleConfirmDelete = () => {
    if (deletingUser) {
      deleteUserMutation.mutate(deletingUser.id);
    }
  };

  const handleAddUser = () => {
    setEditingUser(null);
    setShowEditDialog(true);
  };

  return (
    <div className="max-w-7xl mx-auto max-h-full overflow-auto flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-4xl font-bold mb-2">Team Members</h1>
          <p className="text-gray-400 text-sm">Manage your Air Buddy team</p>
        </div>
        <Button
          onClick={handleAddUser}
          variant="primary"
          className="flex items-center gap-2"
          disabled={createUserMutation.isPending}
        >
          <Plus className="w-5 h-5" />
          <span className="hidden md:inline">Add User</span>
        </Button>
      </div>

      {/* Loading State */}
      {usersQuery.isLoading && (
        <div className="flex justify-center items-center h-64">
          <p className="text-gray-500">Loading users...</p>
        </div>
      )}

      {/* Error State */}
      {usersQuery.isError && (
        <div className="flex justify-center items-center h-64">
          <p className="text-red-500">
            Error loading users. Please try again later.
          </p>
        </div>
      )}

      {/* Users Grid */}
      {usersQuery.isSuccess && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {users.map((user) => (
            <UserCard
              key={user.id}
              user={user}
              onEdit={handleEditUser}
              onDelete={handleDeleteUser}
            />
          ))}
        </div>
      )}

      {/* Edit User Dialog */}
      {showEditDialog && (
        <EditUserDialog
          user={editingUser}
          isOpen={showEditDialog}
          onClose={() => {
            setShowEditDialog(false);
            setEditingUser(null);
          }}
          onSave={handleSaveUser}
          loading={createUserMutation.isPending || updateUserMutation.isPending}
        />
      )}

      {/* Delete Confirmation Dialog */}
      {showDeleteDialog && deletingUser && (
        <DeleteConfirmDialog
          user={deletingUser}
          isOpen={showDeleteDialog}
          onClose={() => {
            setShowDeleteDialog(false);
            setDeletingUser(null);
          }}
          onConfirm={handleConfirmDelete}
          loading={deleteUserMutation.isPending}
        />
      )}
    </div>
  );
};
