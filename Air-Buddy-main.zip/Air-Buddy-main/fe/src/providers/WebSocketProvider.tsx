import { WebSocketContext } from "@/context/WebSocketContext";
import { useEffect, useRef, useState } from "react";
import { io, Socket } from "socket.io-client";

export const WebSocketProvider = ({
  children,
}: {
  children: Readonly<React.ReactNode>;
}) => {
  const socketRef = useRef<Socket | null>(null);
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    socketRef.current = io("/");

    socketRef.current.on("connect", () => {
      setIsConnected(true);
    });

    socketRef.current.on("disconnect", () => {
      setIsConnected(false);
    });

    return () => {
      socketRef.current?.disconnect();
    };
  }, []);

  const subscribe = (event: string, callback: (data: any) => void) => {
    if (!socketRef.current || !isConnected) {
      console.warn(`Socket not ready, couldn't subscribe to ${event}`);
      return;
    }
    socketRef.current.on(event, callback);
  };

  const unsubscribe = (event: string) => {
    if (!socketRef.current) return;
    socketRef.current.off(event);
  };

  return (
    <WebSocketContext.Provider
      value={{
        socket: socketRef.current,
        subscribe,
        unsubscribe,
        isConnected,
      }}
    >
      {children}
    </WebSocketContext.Provider>
  );
};
