import { AuthOnlyRoute } from "@/components/auth-only-route";
import DevicesGrid from "@/components/devices-grid";
import { ProtectedRoute } from "@/components/protected-route";
import { Home } from "@/pages/home";
import { Login } from "@/pages/login";
import { Settings } from "@/pages/settings";
import { Statistics } from "@/pages/statistics";
import { Users } from "@/pages/users";
import { WebSocketProvider } from "@/providers/WebSocketProvider";
import { Route, Routes } from "react-router-dom";
import { paths } from "./routes";

export const Router = () => {
  return (
    <Routes>
      <Route
        path={paths.HOME}
        element={
          <ProtectedRoute>
            <WebSocketProvider>
              <Home />
            </WebSocketProvider>
          </ProtectedRoute>
        }
      >
        <Route index element={<DevicesGrid />} />
        <Route
          path={paths.STATISTICS}
          element={
            <ProtectedRoute>
              <Statistics />
            </ProtectedRoute>
          }
        />
        <Route
          path={paths.SETTINGS}
          element={
            <ProtectedRoute>
              <Settings />
            </ProtectedRoute>
          }
        />
        <Route
          path={paths.USERS}
          element={
            <ProtectedRoute>
              <Users />
            </ProtectedRoute>
          }
        />
      </Route>
      <Route
        path={paths.LOGIN}
        element={
          <AuthOnlyRoute>
            <Login />
          </AuthOnlyRoute>
        }
      />
    </Routes>
  );
};
