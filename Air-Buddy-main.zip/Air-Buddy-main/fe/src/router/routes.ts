export const paths = {
  HOME: "",
  LOGIN: "login",
  STATISTICS: "statistics",
  SETTINGS: "settings",
  USERS: "users",
  USERS_CREATE: "users/create",
  USERS_EDIT: "users/edit/:id",
};
