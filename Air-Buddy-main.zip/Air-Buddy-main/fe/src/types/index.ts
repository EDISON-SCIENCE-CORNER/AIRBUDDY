export interface SensorHistory {
  values: Record<string, number>;
  updatedAt: string;
  createdAt: string;
}

export interface Settings {
  settings: Record<string, number>;
}

export interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  password?: string;
  isAdmin: boolean;
  profilePicUrl?: string;
  isActive: boolean;
}
