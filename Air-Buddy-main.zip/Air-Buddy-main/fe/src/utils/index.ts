import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

declare global {
  interface Window {
    swRegistration?: ServiceWorkerRegistration;
  }
}

export function registerServiceWorker() {
  if ("serviceWorker" in navigator && "PushManager" in window) {
    window.addEventListener("load", () => {
      navigator.serviceWorker
        .register("/sw.js") // Path to your service worker
        .then((swReg) => {
          console.log("Service Worker is registered", swReg);

          window.swRegistration = swReg;
        })
        .catch((err) => {
          console.error("Service Worker registration failed:", err);
        });
    });
  } else {
    console.warn("Push messaging is not supported");
  }
}

export function urlBase64ToUint8Array(base64String: string) {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");

  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);

  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}
