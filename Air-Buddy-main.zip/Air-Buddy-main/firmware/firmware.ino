#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <ESPAsyncWebServer.h>
#include <LittleFS.h>
#include <DNSServer.h>

// --- Configuration ---
#define TRIGGER_PIN 21
#define CONFIG_FILE "/config.json"
#define AP_SSID "ESP32-Setup"

const char* apiEndpoint = "/api/sensor-history";

// --- Global variables ---
struct Config {
  char wifi_ssid[33] = "edison science corner";
  char wifi_password[65] = "eeeeeeee";
  char server_url[100] = "https://air-buddy.onrender.com"; 
  char access_token[70] = "4557064fcd4a9283b12e22fdc9afea4de0ab4ec0edb017fada93af9ace457a8f";     
};

Config config;
AsyncWebServer server(80);
DNSServer dnsServer;
bool inConfigMode = false;

// --- Function Declarations ---
bool loadConfig();
bool saveConfig();
void startAccessPoint();
void startConfigMode();
void setupWebServer();
bool connectToWiFi();
void handleGetConfig(AsyncWebServerRequest *request);
void handlePostConfig(AsyncWebServerRequest *request);
void sendSensorData();

// --- Setup ---
void setup() {
  Serial.begin(115200);
  Serial.println("\n\nBooting...");

  pinMode(TRIGGER_PIN, INPUT_PULLUP);

  if (!LittleFS.begin()) {
    Serial.println("ERROR: Failed to mount LittleFS. Formatting...");
    LittleFS.format();
    return;
  }
  Serial.println("LittleFS mounted successfully.");

  bool triggerActive = (digitalRead(TRIGGER_PIN) == HIGH);
  if (triggerActive) {
    Serial.println("INFO: Trigger pin activated, forcing Config Mode.");
  }

  bool configLoaded = loadConfig();
  
  if (triggerActive || !configLoaded || strlen(config.server_url) == 0 || strlen(config.access_token) == 0) {
    // Enter config mode if trigger is active, no config, or essential config data is missing
    startConfigMode();
    return;
  }

  Serial.println("INFO: Configuration found. Attempting to connect to WiFi...");
  if (connectToWiFi()) {
    inConfigMode = false;
    Serial.println("INFO: WiFi Connected. Proceeding with normal operation.");
    Serial.print("ESP32 IP address: ");
    Serial.println(WiFi.localIP());
    Serial.print("Target Server: ");
    Serial.print(config.server_url);
    Serial.println(apiEndpoint);
  } else {
    Serial.println("ERROR: Failed to connect with saved credentials.");
    startConfigMode();
  }
}

// --- Loop ---
void loop() {
  if (inConfigMode) {
    dnsServer.processNextRequest();
  } else {
    // Continuously send data if not in config mode and WiFi is connected
    if (WiFi.status() == WL_CONNECTED) {
      sendSensorData();
    } else {
      Serial.println("WiFi not connected. Attempting to reconnect...");
      if (connectToWiFi()) {
        Serial.println("WiFi reconnected!");
      } else {
        Serial.println("Failed to reconnect to WiFi. Entering config mode.");
        startConfigMode();
      }
    }
  }
  delay(10); // Small delay to prevent watchdog timer issues and allow other tasks
}

// --- Function Implementations ---

void startConfigMode() {
  inConfigMode = true;
  Serial.println("INFO: Entering Configuration Mode.");
  
  startAccessPoint();
  setupWebServer();
  server.begin();
  
  Serial.println("INFO: Configuration server with Captive Portal is active.");
  Serial.print("INFO: Connect to AP: ");
  Serial.println(AP_SSID);
  Serial.print("INFO: Go to http://");
  Serial.println(WiFi.softAPIP());
}

bool loadConfig() {
  if (!LittleFS.exists(CONFIG_FILE)) {
    Serial.println("WARN: Configuration file not found.");
    return false;
  }

  File configFile = LittleFS.open(CONFIG_FILE, "r");
  if (!configFile) {
    Serial.println("ERROR: Failed to open config file for reading.");
    return false;
  }

  StaticJsonDocument<512> doc;
  DeserializationError error = deserializeJson(doc, configFile);
  configFile.close();

  if (error) {
    Serial.print("ERROR: Failed to parse config file: ");
    Serial.println(error.c_str());
    return false;
  }

  strlcpy(config.wifi_ssid, doc["wifi_ssid"] | "", sizeof(config.wifi_ssid));
  strlcpy(config.wifi_password, doc["wifi_password"] | "", sizeof(config.wifi_password));
  strlcpy(config.server_url, doc["server_url"] | "", sizeof(config.server_url));
  strlcpy(config.access_token, doc["access_token"] | "", sizeof(config.access_token));
  
  if (strlen(config.wifi_ssid) == 0) {
    Serial.println("WARN: Loaded configuration has an empty SSID.");
    return false;
  }
  
  Serial.print("INFO: Loaded SSID from config: ");
  Serial.println(config.wifi_ssid);
  Serial.print("INFO: Loaded Server Address from config: ");
  Serial.println(config.server_url);
  return true;
}

bool saveConfig() {
  StaticJsonDocument<512> doc;
  doc["wifi_ssid"] = config.wifi_ssid;
  doc["wifi_password"] = config.wifi_password;
  doc["server_url"] = config.server_url;
  doc["access_token"] = config.access_token;

  File configFile = LittleFS.open(CONFIG_FILE, "w");
  if (!configFile) {
    Serial.println("ERROR: Failed to open config file for writing.");
    return false;
  }

  if (serializeJson(doc, configFile) == 0) {
    Serial.println("ERROR: Failed to write to config file.");
    configFile.close();
    return false;
  }

  configFile.close();
  Serial.println("INFO: Configuration saved successfully.");
  return true;
}

void startAccessPoint() {
  Serial.println("INFO: Starting Access Point (AP) and DNS server...");
  WiFi.mode(WIFI_AP);
  WiFi.softAP(AP_SSID);
  IPAddress apIP = WiFi.softAPIP();
  dnsServer.start(53, "*", apIP);
}

void setupWebServer() {
  Serial.println("INFO: Setting up Web Server routes for configuration...");
  server.onNotFound([](AsyncWebServerRequest *request) {
      request->send(LittleFS, "/index.html", "text/html");
  });
  server.serveStatic("/", LittleFS, "/").setDefaultFile("index.html");
  server.on("/api/config", HTTP_GET, handleGetConfig);
  server.on("/api/config", HTTP_POST, handlePostConfig);
}

void handleGetConfig(AsyncWebServerRequest *request) {
  StaticJsonDocument<512> doc;
  doc["wifi_ssid"] = config.wifi_ssid;
  doc["server_url"] = config.server_url;
  doc["access_token"] = config.access_token; 
  String jsonResponse;
  serializeJson(doc, jsonResponse);
  request->send(200, "application/json", jsonResponse);
}

void handlePostConfig(AsyncWebServerRequest *request) {
  if (request->hasParam("wifi_ssid", true)) {
    strlcpy(config.wifi_ssid, request->getParam("wifi_ssid", true)->value().c_str(), sizeof(config.wifi_ssid));
    Serial.print("INFO: Received SSID for saving: ");
    Serial.println(config.wifi_ssid);
  }
  if (request->hasParam("wifi_password", true)) {
    strlcpy(config.wifi_password, request->getParam("wifi_password", true)->value().c_str(), sizeof(config.wifi_password));
    Serial.println("INFO: Received password for saving.");
  }
  if (request->hasParam("server_url", true)) {
    strlcpy(config.server_url, request->getParam("server_url", true)->value().c_str(), sizeof(config.server_url));
    Serial.print("INFO: Received Server Address for saving: ");
    Serial.println(config.server_url);
  }
  if (request->hasParam("access_token", true)) {
    strlcpy(config.access_token, request->getParam("access_token", true)->value().c_str(), sizeof(config.access_token));
    Serial.println("INFO: Received API Key for saving.");
  }

  if (saveConfig()) {
    request->send(200, "text/plain", "Configuration updated. Restarting...");
    Serial.println("INFO: Restarting in 3 seconds...");
    delay(3000);
    ESP.restart();
  } else {
    request->send(500, "text/plain", "Error saving configuration.");
  }
}

bool connectToWiFi() {
  Serial.print("INFO: Connecting to WiFi SSID: ");
  Serial.println(config.wifi_ssid);
  WiFi.mode(WIFI_STA);
  WiFi.begin(config.wifi_ssid, config.wifi_password);
  unsigned long startTime = millis();
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
    if (millis() - startTime > 20000) {
      Serial.println("\nERROR: WiFi connection timed out.");
      WiFi.disconnect(true);
      WiFi.mode(WIFI_OFF);
      return false;
    }
  }
  Serial.println("\nWiFi connected!");
  return true;
}

void sendSensorData() {
  HTTPClient http;

  String serverPath = String(config.server_url) + String(apiEndpoint);
  Serial.print("\nAttempting POST request to: ");
  Serial.println(serverPath);

  http.begin(serverPath);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("X-API-Key", config.access_token);

  // Generate sensor values matching the new sensor types
  float temperature = random(250, 270) / 10.0;  // 18.0-28.0°C
  int humidity = random(70, 72);                // 30-70%
  int co = random(0, 2);                         // 0-10 ppm
  int no2 = 0;                        // 0-50 ppm

  StaticJsonDocument<256> doc;
  JsonObject values = doc.createNestedObject("values");
  values["Temperature"] = temperature;
  values["Humidity"] = humidity;
  values["CO"] = co;
  values["NO2"] = no2;

  String jsonPayload;
  serializeJson(doc, jsonPayload);

  Serial.print("Sending JSON payload: ");
  Serial.println(jsonPayload);

  int httpResponseCode = http.POST(jsonPayload);

  if (httpResponseCode > 0) {
    Serial.printf("HTTP Response code: %d\n", httpResponseCode);
    String responsePayload = http.getString();
    Serial.println("Server Response:");
    Serial.println(responsePayload);
  } else {
    Serial.printf("HTTP Error: %s\n", http.errorToString(httpResponseCode).c_str());
  }

  http.end();
}

long random(long min, long max) {
  return min + rand() % (max - min + 1);
}
